import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'package:whatsapp_clone/screens/contacts/models/contact_profile.dart';
import 'package:whatsapp_clone/screens/contacts/models/contact_manager.dart';
import 'package:whatsapp_clone/constants/colors.dart';
import 'package:permission_handler/permission_handler.dart';

class ContactProfileScreen extends StatefulWidget {
  final String contactId;

  const ContactProfileScreen({Key? key, required this.contactId}) : super(key: key);

  @override
  _ContactProfileScreenState createState() => _ContactProfileScreenState();
}

class _ContactProfileScreenState extends State<ContactProfileScreen> {
  late ContactProfile contact;
  final ImagePicker _picker = ImagePicker();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _bioController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  bool _isEditing = false;

  @override
  void initState() {
    super.initState();
    contact = ContactManager.getContact(widget.contactId) ?? 
              ContactProfile(id: widget.contactId, name: 'Unknown', phone: '');
    _loadContactData();
  }

  void _loadContactData() {
    _nameController.text = contact.name;
    _phoneController.text = contact.phone;
    _bioController.text = contact.bio ?? '';
    _emailController.text = contact.email ?? '';
  }

  Future<void> _pickAvatar() async {
    try {
      final XFile? image = await _picker.pickImage(
        source: ImageSource.gallery,
        maxWidth: 512,
        maxHeight: 512,
        imageQuality: 75,
      );

      if (image != null) {
        setState(() {
          contact = contact.copyWith(avatarPath: image.path);
        });
        ContactManager.updateContactAvatar(widget.contactId, image.path);

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Avatar updated!'),
            backgroundColor: kPrimaryColor,
            duration: Duration(seconds: 2),
          ),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to pick image: $e'),
          backgroundColor: Colors.red,
          duration: Duration(seconds: 2),
        ),
      );
    }
  }

  void _saveChanges() {
    final updatedContact = contact.copyWith(
      name: _nameController.text,
      phone: _phoneController.text,
      bio: _bioController.text,
      email: _emailController.text,
    );
    
    ContactManager.updateContact(updatedContact);
    setState(() {
      contact = updatedContact;
      _isEditing = false;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Contact updated successfully!'),
        backgroundColor: kPrimaryColor,
        duration: Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          _isEditing ? "Edit Contact" : "Contact Profile",
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: Colors.black,
          ),
        ),
        actions: [
          if (!_isEditing)
            IconButton(
              icon: Icon(Icons.edit, color: kPrimaryColor),
              onPressed: () {
                setState(() {
                  _isEditing = true;
                });
              },
            ),
          if (_isEditing) ...[
            IconButton(
              icon: Icon(Icons.close, color: Colors.red),
              onPressed: () {
                setState(() {
                  _isEditing = false;
                  _loadContactData(); // Reset to original data
                });
              },
            ),
            IconButton(
              icon: Icon(Icons.check, color: kPrimaryColor),
              onPressed: _saveChanges,
            ),
          ],
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // Avatar Section
            Container(
              padding: EdgeInsets.all(20),
              child: Column(
                children: [
                  GestureDetector(
                    onTap: _isEditing ? _pickAvatar : null,
                    child: Stack(
                      children: [
                        CircleAvatar(
                          radius: 60,
                          backgroundImage: contact.avatarPath != null 
                              ? FileImage(File(contact.avatarPath!))
                              : null,
                          backgroundColor: contact.avatarPath == null ? Colors.grey[300] : null,
                          child: contact.avatarPath == null
                              ? Icon(Icons.person, color: Colors.grey[600], size: 60)
                              : null,
                        ),
                        if (_isEditing)
                          Positioned(
                            bottom: 0,
                            right: 0,
                            child: Container(
                              width: 35,
                              height: 35,
                              decoration: BoxDecoration(
                                color: kPrimaryColor,
                                shape: BoxShape.circle,
                                border: Border.all(color: Colors.white, width: 3),
                              ),
                              child: Icon(Icons.camera_alt, color: Colors.white, size: 18),
                            ),
                          ),
                      ],
                    ),
                  ),
                  SizedBox(height: 16),
                  if (_isEditing)
                    Text(
                      "Tap to change avatar",
                      style: TextStyle(
                        fontSize: 16,
                        color: kPrimaryColor,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                ],
              ),
            ),
            Divider(height: 1),
            
            // Name Section
            _buildEditableSection(
              label: "Name",
              controller: _nameController,
              icon: Icons.person,
              isEditing: _isEditing,
            ),
            
            // Phone Section
            _buildEditableSection(
              label: "Phone",
              controller: _phoneController,
              icon: Icons.phone,
              isEditing: _isEditing,
              keyboardType: TextInputType.phone,
            ),
            
            // Email Section
            _buildEditableSection(
              label: "Email",
              controller: _emailController,
              icon: Icons.email,
              isEditing: _isEditing,
              keyboardType: TextInputType.emailAddress,
            ),
            
            // Bio Section
            _buildEditableSection(
              label: "About",
              controller: _bioController,
              icon: Icons.info,
              isEditing: _isEditing,
              maxLines: 3,
            ),
            
            // Last Seen Section (Read Only)
            if (!_isEditing && contact.lastSeen != null)
              Container(
                padding: EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(Icons.access_time, color: Colors.grey[600], size: 20),
                        SizedBox(width: 12),
                        Text(
                          "Last seen",
                          style: TextStyle(
                            fontSize: 14,
                            color: kPrimaryColor,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 8),
                    Padding(
                      padding: EdgeInsets.only(left: 32),
                      child: Text(
                        _formatLastSeen(contact.lastSeen!),
                        style: TextStyle(
                          fontSize: 16,
                          color: Colors.black,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildEditableSection({
    required String label,
    required TextEditingController controller,
    required IconData icon,
    required bool isEditing,
    TextInputType? keyboardType,
    int maxLines = 1,
  }) {
    return Container(
      padding: EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: Colors.grey[600], size: 20),
              SizedBox(width: 12),
              Text(
                label,
                style: TextStyle(
                  fontSize: 14,
                  color: kPrimaryColor,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
          SizedBox(height: 8),
          if (isEditing)
            Padding(
              padding: EdgeInsets.only(left: 32),
              child: TextField(
                controller: controller,
                keyboardType: keyboardType,
                maxLines: maxLines,
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.black,
                ),
                decoration: InputDecoration(
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide(color: Colors.grey[300]!),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide(color: kPrimaryColor),
                  ),
                  contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                ),
              ),
            )
          else
            Padding(
              padding: EdgeInsets.only(left: 32),
              child: Text(
                controller.text.isEmpty ? 'Not set' : controller.text,
                style: TextStyle(
                  fontSize: 16,
                  color: controller.text.isEmpty ? Colors.grey[400] : Colors.black,
                ),
              ),
            ),
        ],
      ),
    );
  }

  String _formatLastSeen(DateTime lastSeen) {
    final now = DateTime.now();
    final difference = now.difference(lastSeen);
    
    if (difference.inDays > 0) {
      return '${difference.inDays} day${difference.inDays > 1 ? 's' : ''} ago';
    } else if (difference.inHours > 0) {
      return '${difference.inHours} hour${difference.inHours > 1 ? 's' : ''} ago';
    } else if (difference.inMinutes > 0) {
      return '${difference.inMinutes} minute${difference.inMinutes > 1 ? 's' : ''} ago';
    } else {
      return 'Just now';
    }
  }
}
