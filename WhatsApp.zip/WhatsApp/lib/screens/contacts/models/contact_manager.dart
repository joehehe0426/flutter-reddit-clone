import 'package:whatsapp_clone/screens/contacts/models/contact_profile.dart';
import 'package:whatsapp_clone/models/users.dart';

class ContactManager {
  static final Map<String, ContactProfile> _contacts = {};
  
  // Initialize with default contacts from users.dart
  static void initializeContacts() {
    for (User user in users) {
      final hashString = user.id.hashCode.toString();
      final firstPart = hashString.length >= 4 ? hashString.substring(0, 4) : hashString.padRight(4, '0');
      final secondPart = hashString.length >= 8 ? hashString.substring(4, 8) : hashString.padRight(8, '0').substring(4, 8);
      
      _contacts[user.id] = ContactProfile(
        id: user.id,
        name: user.username,
        phone: '+852 $firstPart $secondPart',
        avatarPath: null, // Will be set when user selects avatar
        bio: 'Hey there! I\'m using WhatsApp.',
        email: '${user.username.toLowerCase().replaceAll(' ', '.')}@example.com',
        lastSeen: DateTime.now().subtract(Duration(hours: user.id.hashCode % 24)),
      );
    }
  }

  // Get all contacts
  static List<ContactProfile> getAllContacts() {
    return _contacts.values.toList();
  }

  // Get contact by ID
  static ContactProfile? getContact(String id) {
    return _contacts[id];
  }

  // Get contact by display name
  static ContactProfile? getContactByName(String name) {
    try {
      return _contacts.values.firstWhere((c) => c.name == name);
    } catch (_) {
      return null;
    }
  }

  // Add or update contact
  static void updateContact(ContactProfile contact) {
    _contacts[contact.id] = contact;
  }

  // Update contact avatar
  static void updateContactAvatar(String contactId, String avatarPath) {
    final contact = _contacts[contactId];
    if (contact != null) {
      _contacts[contactId] = contact.copyWith(avatarPath: avatarPath);
    }
  }

  // Update contact info
  static void updateContactInfo(String contactId, {
    String? name,
    String? phone,
    String? bio,
    String? email,
  }) {
    final contact = _contacts[contactId];
    if (contact != null) {
      _contacts[contactId] = contact.copyWith(
        name: name,
        phone: phone,
        bio: bio,
        email: email,
      );
    }
  }

  // Get contact name by ID
  static String getContactName(String id) {
    return _contacts[id]?.name ?? 'Unknown';
  }

  // Get contact avatar path by ID
  static String? getContactAvatar(String id) {
    return _contacts[id]?.avatarPath;
  }

  // Get avatar by display name
  static String? getAvatarByName(String name) {
    return getContactByName(name)?.avatarPath;
  }

  // Check if contact exists
  static bool hasContact(String id) {
    return _contacts.containsKey(id);
  }
}
