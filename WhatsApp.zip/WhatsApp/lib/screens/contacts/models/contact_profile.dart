class ContactProfile {
  final String id;
  final String name;
  final String phone;
  final String? avatarPath;
  final String? bio;
  final String? email;
  final DateTime? lastSeen;

  ContactProfile({
    required this.id,
    required this.name,
    required this.phone,
    this.avatarPath,
    this.bio,
    this.email,
    this.lastSeen,
  });

  // Create a copy with updated fields
  ContactProfile copyWith({
    String? id,
    String? name,
    String? phone,
    String? avatarPath,
    String? bio,
    String? email,
    DateTime? lastSeen,
  }) {
    return ContactProfile(
      id: id ?? this.id,
      name: name ?? this.name,
      phone: phone ?? this.phone,
      avatarPath: avatarPath ?? this.avatarPath,
      bio: bio ?? this.bio,
      email: email ?? this.email,
      lastSeen: lastSeen ?? this.lastSeen,
    );
  }

  // Convert to Map for storage
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'phone': phone,
      'avatarPath': avatarPath,
      'bio': bio,
      'email': email,
      'lastSeen': lastSeen?.toIso8601String(),
    };
  }

  // Create from Map
  factory ContactProfile.fromMap(Map<String, dynamic> map) {
    return ContactProfile(
      id: map['id'] ?? '',
      name: map['name'] ?? '',
      phone: map['phone'] ?? '',
      avatarPath: map['avatarPath'],
      bio: map['bio'],
      email: map['email'],
      lastSeen: map['lastSeen'] != null ? DateTime.parse(map['lastSeen']) : null,
    );
  }
}
