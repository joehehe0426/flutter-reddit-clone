import 'package:flutter/material.dart';
import 'dart:io';
import 'package:whatsapp_clone/screens/contacts/models/contact_profile.dart';
import 'package:whatsapp_clone/screens/contacts/models/contact_manager.dart';
import 'package:whatsapp_clone/screens/contacts/contact_profile_screen.dart';
import 'package:whatsapp_clone/constants/colors.dart';

class ContactsListScreen extends StatefulWidget {
  const ContactsListScreen({Key? key}) : super(key: key);

  @override
  _ContactsListScreenState createState() => _ContactsListScreenState();
}

class _ContactsListScreenState extends State<ContactsListScreen> {
  List<ContactProfile> contacts = [];
  String searchQuery = '';

  @override
  void initState() {
    super.initState();
    _loadContacts();
  }

  void _loadContacts() {
    // Initialize contacts if not already done
    ContactManager.initializeContacts();
    setState(() {
      contacts = ContactManager.getAllContacts();
    });
  }

  List<ContactProfile> get filteredContacts {
    if (searchQuery.isEmpty) {
      return contacts;
    }
    return contacts.where((contact) =>
        contact.name.toLowerCase().contains(searchQuery.toLowerCase()) ||
        contact.phone.contains(searchQuery)).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        title: Text(
          "Contacts",
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: Colors.black,
          ),
        ),
        iconTheme: IconThemeData(color: Colors.black),
        actions: [
          IconButton(
            icon: Icon(Icons.search, color: kPrimaryColor),
            onPressed: () {
              // Show search functionality
            },
          ),
          IconButton(
            icon: Icon(Icons.more_vert, color: kPrimaryColor),
            onPressed: () {
              // Show more options
            },
          ),
        ],
      ),
      body: Column(
        children: [
          // Search Bar
          Container(
            padding: EdgeInsets.all(16),
            child: TextField(
              onChanged: (value) {
                setState(() {
                  searchQuery = value;
                });
              },
              decoration: InputDecoration(
                hintText: 'Search contacts...',
                prefixIcon: Icon(Icons.search, color: Colors.grey),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(25),
                  borderSide: BorderSide(color: Colors.grey[300]!),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(25),
                  borderSide: BorderSide(color: kPrimaryColor),
                ),
                filled: true,
                fillColor: Colors.grey[100],
                contentPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              ),
            ),
          ),
          
          // Contacts List
          Expanded(
            child: filteredContacts.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.people_outline,
                          size: 64,
                          color: Colors.grey[400],
                        ),
                        SizedBox(height: 16),
                        Text(
                          searchQuery.isEmpty 
                              ? 'No contacts found'
                              : 'No contacts match "$searchQuery"',
                          style: TextStyle(
                            fontSize: 16,
                            color: Colors.grey[600],
                          ),
                        ),
                      ],
                    ),
                  )
                : ListView.builder(
                    itemCount: filteredContacts.length,
                    itemBuilder: (context, index) {
                      final contact = filteredContacts[index];
                      return _buildContactTile(contact);
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildContactTile(ContactProfile contact) {
    return ListTile(
      leading: CircleAvatar(
        radius: 25,
        backgroundImage: contact.avatarPath != null 
            ? FileImage(File(contact.avatarPath!))
            : null,
        backgroundColor: contact.avatarPath == null ? Colors.grey[300] : null,
        child: contact.avatarPath == null
            ? Text(
                contact.name.isNotEmpty ? contact.name[0].toUpperCase() : '?',
                style: TextStyle(
                  color: Colors.grey[600],
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                ),
              )
            : null,
      ),
      title: Text(
        contact.name,
        style: TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.w500,
          color: Colors.black,
        ),
      ),
      subtitle: Text(
        contact.phone,
        style: TextStyle(
          fontSize: 14,
          color: Colors.grey[600],
        ),
      ),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          IconButton(
            icon: Icon(Icons.message, color: kPrimaryColor, size: 20),
            onPressed: () {
              // Navigate to chat with this contact
              Navigator.pop(context, contact.id);
            },
          ),
          IconButton(
            icon: Icon(Icons.call, color: kPrimaryColor, size: 20),
            onPressed: () {
              // Call this contact
            },
          ),
        ],
      ),
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => ContactProfileScreen(contactId: contact.id),
          ),
        ).then((_) {
          // Refresh contacts when returning from profile screen
          _loadContacts();
        });
      },
    );
  }
}
