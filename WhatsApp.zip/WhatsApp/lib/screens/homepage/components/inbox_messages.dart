import 'package:flutter/material.dart';
import 'package:whatsapp_clone/constants/colors.dart';
import 'package:whatsapp_clone/models/messages.dart';
import 'package:whatsapp_clone/models/users.dart';
import 'package:whatsapp_clone/models/group_avatar_manager.dart';
import 'dart:io';

class MessagesWidget extends StatefulWidget {
  final User user;
  final String message;
  final String timeStamp;
  final ChatMessage messageTick;

  const MessagesWidget({
    super.key,
    required this.user,
    required this.message,
    required this.timeStamp,
    required this.messageTick,
  });

  @override
  State<MessagesWidget> createState() => _MessagesWidgetState();
}

class _MessagesWidgetState extends State<MessagesWidget> {
  String? _customAvatarPath;

  @override
  void initState() {
    super.initState();
    _loadCustomAvatar();
  }

  Future<void> _loadCustomAvatar() async {
    // Check if it's a group chat
    if (widget.user.id.startsWith('hk_') || widget.user.username.contains('群')) {
      final savedAvatar = await GroupAvatarManager.getGroupAvatar(widget.user.id);
      if (savedAvatar != null && mounted) {
        // Check if the file still exists
        final file = File(savedAvatar);
        if (await file.exists()) {
          setState(() {
            _customAvatarPath = savedAvatar;
          });
        } else {
          // File doesn't exist, remove the saved path
          await GroupAvatarManager.removeGroupAvatar(widget.user.id);
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
      leading: CircleAvatar(
        backgroundColor: Colors.grey,
        backgroundImage: _customAvatarPath != null
          ? FileImage(File(_customAvatarPath!))
          : AssetImage(widget.user.profilePicture) as ImageProvider,
        radius: 25.0,
      ),
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            widget.user.username,
            style: const TextStyle(
              color: kTextColor,
              fontWeight: FontWeight.w500,
            ),
          ),
          Text(
            widget.timeStamp,
            style: const TextStyle(
              color: kTextDarkColor,
              fontSize: 12.0,
            ),
          ),
        ],
      ),
      subtitle: Row(
        children: [
          if(widget.messageTick.isSender)
            Icon(
              widget.messageTick.isReceived ? Icons.done_all : Icons.done,
              color: widget.messageTick.isRead ? kBlueTickColor : Colors.grey,
              size: 16.0,
            ),
          if(widget.messageTick.isSender)
            const SizedBox(width: 5.0),
          Expanded(
            child: Text(
              widget.message,
              style: const TextStyle(
                color: kTextDarkColor,
              ),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }
}
