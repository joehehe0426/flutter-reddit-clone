import 'package:flutter/material.dart';
import 'package:whatsapp_clone/constants/colors.dart';
import 'package:whatsapp_clone/screens/settings/settings_screen.dart';

AppBar homepageHeader(BuildContext context) {
  return AppBar(
    backgroundColor: Colors.white,
    automaticallyImplyLeading: false,
    title: const Text(
      'WhatsApp',
      style: TextStyle(
        fontSize: 22.0,
        fontWeight: FontWeight.bold,
        color: Color(0xFF128C7E), // Slightly darker green
      ),
    ),
    iconTheme: const IconThemeData(
      color: Colors.black, // Added missing closing parenthesis
    ),
    actions: [
      IconButton(
        onPressed: () {}, 
        icon: const Icon(Icons.camera_alt_outlined),
        tooltip: 'Camera',
      ),
      IconButton(
        onPressed: () {}, 
        icon: const Icon(Icons.search_outlined),
        tooltip: 'Search',
      ),
      IconButton(
        onPressed: () => Navigator.pushNamed(
          context, 
          SettingsScreen.routeName
        ), 
        icon: const Icon(Icons.more_vert),
        tooltip: 'More options',
      ),
    ],
  );
}
