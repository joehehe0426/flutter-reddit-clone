import 'package:flutter/material.dart';
import 'package:whatsapp_clone/models/users.dart';
import 'package:whatsapp_clone/models/messages.dart';
import 'package:whatsapp_clone/screens/chats/chat_screen.dart';
import 'package:whatsapp_clone/screens/homepage/components/inbox_messages.dart';
import 'package:whatsapp_clone/constants/colors.dart';


class HomepageBody extends StatefulWidget {
  const HomepageBody({super.key});

  @override
  State<HomepageBody> createState() => _HomepageBodyState();
}

class _HomepageBodyState extends State<HomepageBody> {
  List<User> _visibleUsers = [];

  @override
  void initState() {
    super.initState();
    // Initialize and sort: pin threads (ids starting with 'pin_'), then HK demo threads ('hk_')
    _visibleUsers = [...users]
      ..sort((a, b) {
        final aPin = a.id.startsWith('pin_');
        final bPin = b.id.startsWith('pin_');
        if (aPin != bPin) return aPin ? -1 : 1;
        final aIsHk = a.id.startsWith('hk_');
        final bIsHk = b.id.startsWith('hk_');
        if (aIsHk == bIsHk) return 0;
        return aIsHk ? -1 : 1;
      });
  }

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: _visibleUsers.length,
      itemBuilder: (context, int index) {
        final user = _visibleUsers[index];
        final userId = user.id;
        final userMsgs = userChatHistories[userId] ?? [];
        final ChatMessage lastMsg = userMsgs.isNotEmpty ? userMsgs.last : ChatMessage(message: '', timeStamp: '', isSender: false, date: '');

        return Dismissible(
          key: ValueKey(user.id),
          direction: DismissDirection.endToStart,
          background: Container(
            color: kPrimaryColor,
            alignment: Alignment.centerRight,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: const Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Icon(Icons.delete_outline, color: Colors.white),
                SizedBox(width: 8),
                Text('刪除', style: TextStyle(color: Colors.white)),
              ],
            ),
          ),
          confirmDismiss: (direction) async {
            return await showDialog<bool>(
              context: context,
              builder: (ctx) => AlertDialog(
                title: const Text('刪除聊天？'),
                content: Text('確定要刪除與「${user.username}」的聊天嗎？'),
                actions: [
                  TextButton(onPressed: () => Navigator.of(ctx).pop(false), child: const Text('取消')),
                  TextButton(onPressed: () => Navigator.of(ctx).pop(true), child: const Text('刪除')),
                ],
              ),
            );
          },
          onDismissed: (direction) {
            final removedUser = user;
            final removedIndex = index;
            setState(() {
              _visibleUsers.removeAt(index);
            });
            ScaffoldMessenger.of(context).clearSnackBars();
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('已刪除「${removedUser.username}」'),
                action: SnackBarAction(
                  label: '復原',
                  onPressed: () {
                    setState(() {
                      _visibleUsers.insert(removedIndex, removedUser);
                    });
                  },
                ),
              ),
            );
          },
          child: InkWell(
            onTap: () => Navigator.pushNamed(
              context,
              ChatScreen.routeName,
              arguments: userId,
            ),
            child: MessagesWidget(
              user: user,
              message: lastMsg.message,
              timeStamp: lastMsg.timeStamp,
              messageTick: lastMsg,
            ),
          ),
        );
      }
    );
  }
}