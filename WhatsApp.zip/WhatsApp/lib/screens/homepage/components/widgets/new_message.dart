import 'package:flutter/material.dart';
import 'package:whatsapp_clone/screens/chats/flutter_chat_screen.dart';


class NewMessageWidget extends StatelessWidget {
  const NewMessageWidget({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return FloatingActionButton(
      backgroundColor: const Color(0xFF128C7E),
      onPressed: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => const FlutterChatScreen(userId: 'demo_user'),
          ),
        );
      },
      child: const Icon(Icons.add_comment, color: Colors.white, size: 25.0),
    );
  }
}
