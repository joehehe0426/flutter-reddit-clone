import 'package:flutter/material.dart';
import 'package:whatsapp_clone/constants/colors.dart';


class UpdatesIconWidget extends StatelessWidget {
  final IconData icon;
  const UpdatesIconWidget({
    super.key,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Icon(icon);
  }
}