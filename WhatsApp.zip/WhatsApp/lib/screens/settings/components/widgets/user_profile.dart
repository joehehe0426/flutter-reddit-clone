import 'package:flutter/material.dart';
import 'package:whatsapp_clone/constants/colors.dart';
import 'package:whatsapp_clone/screens/profile/profile_page.dart';
import 'package:whatsapp_clone/models/user_profile.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import 'dart:io' show Platform;

class UserProfileInfo extends StatefulWidget {
  const UserProfileInfo({
    super.key,
  });

  @override
  State<UserProfileInfo> createState() => _UserProfileInfoState();
}

class _UserProfileInfoState extends State<UserProfileInfo> {
  final ImagePicker _picker = ImagePicker();

  Future<void> _pickImage() async {
    // On iOS, request Photos permission explicitly. On Android, let image_picker handle it.
    if (Platform.isIOS) {
      PermissionStatus status = await Permission.photos.status;
      if (status.isDenied || status.isRestricted) {
        status = await Permission.photos.request();
      }
      if (status.isPermanentlyDenied) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('Permission required to access gallery'),
            backgroundColor: Colors.orange,
            action: SnackBarAction(
              label: 'Open Settings',
              onPressed: openAppSettings,
            ),
          ),
        );
        return;
      }
      if (!status.isGranted) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Permission required to access gallery'),
            backgroundColor: Colors.orange,
          ),
        );
        return;
      }
    }

    try {
      final XFile? image = await _picker.pickImage(
        source: ImageSource.gallery,
        maxWidth: 1024,
        maxHeight: 1024,
        imageQuality: 85,
      );
      if (image != null) {
        setState(() {
          UserProfile.updateProfilePicture(image.path);
        });
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error picking image: ${e.toString()}'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: GestureDetector(
        onTap: _pickImage,
        child: Stack(
          children: [
            UserProfile.getProfileImage(radius: 30.0),
            Positioned(
              bottom: 0,
              right: 0,
              child: Container(
                decoration: const BoxDecoration(
                  color: kPrimaryColor,
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.camera_alt,
                  color: Colors.white,
                  size: 16,
                ),
              ),
            ),
          ],
        ),
      ),
      title: Text(
        UserProfile.username,
        style: const TextStyle(
          color: kTextColor,
          fontSize: 18.0,
          overflow: TextOverflow.ellipsis,
        ),
      ),
      subtitle: Text(
        UserProfile.bio,
        style: const TextStyle(
          color: kTextDarkColor,
          fontSize: 14.0,
          overflow: TextOverflow.ellipsis,
        ),
      ),
      trailing: SizedBox(
        width: MediaQuery.of(context).size.width * .25,
        child: Row(
          children: [
            IconButton(
              onPressed: () {}, 
              icon: const Icon(Icons.qr_code, color: kPrimaryColor),
            ),
                                    IconButton(
                          onPressed: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => ProfilePage(
                                profileImage: UserProfile.profileImagePath,
                                userName: UserProfile.username,
                              ),
                            ),
                          ),
                          icon: const Icon(Icons.expand_circle_down_outlined, color: kPrimaryColor),
                        ),
          ],
        ),
      ),
    );
  }
}