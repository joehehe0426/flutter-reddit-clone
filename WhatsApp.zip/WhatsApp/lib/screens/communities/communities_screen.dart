import 'package:flutter/material.dart';
import 'package:whatsapp_clone/screens/communities/components/appbar.dart';
// import 'package:whatsapp_clone/screens/communities/components/add_community.dart';
// import 'package:whatsapp_clone/screens/communities/components/community_card.dart';
import 'package:whatsapp_clone/constants/colors.dart';


class CommunitiesScreen extends StatelessWidget {
  const CommunitiesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kbackgroundColor,
      appBar: communitiesAppBar(),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20.0),
        child: Center(
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                // Illustration
                Image.asset(
                  'assets/img/whatsapp-doodle-circle.png',
                  width: MediaQuery.of(context).size.width * .6,
                ),
                const SizedBox(height: 20.0),
                // Headline
                const Text(
                  'Stay connected with a community',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: kTextColor,
                    fontSize: 24.0,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 10.0),
                const Text(
                  'Communities bring members together in topic-based groups, and make it easy to get admin announcements. Any community you\'re added to will appear here.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: kTextDarkColor,
                    height: 1.4,
                  ),
                ),
                const SizedBox(height: 16.0),
                // Link
                TextButton(
                  onPressed: () {},
                  child: const Text(
                    'See example communities',
                    style: TextStyle(color: Colors.blue),
                  ),
                ),
                const SizedBox(height: 10.0),
                // Primary button
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () {},
                    style: ElevatedButton.styleFrom(
                      backgroundColor: kPrimaryColor,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 14.0),
                      shape: const StadiumBorder(),
                    ),
                    child: const Text('Start your community'),
                  ),
                ),
                const SizedBox(height: 20.0),
              ],
            ),
          ),
        ),
      ),
    );
  }
}