import 'package:flutter/material.dart';


AppBar communitiesAppBar() {
  return AppBar(
    automaticallyImplyLeading: false,
    title: const Text(
      'Communities',
      style: TextStyle(
        fontSize: 20.0,
      ),
    ),
    actions: [
      IconButton(
        onPressed: () {}, 
        icon: const Icon(Icons.camera_alt_outlined),
      ),
      PopupMenuButton<String>(
        icon: const Icon(Icons.more_vert),
        onSelected: (value) {
          // Handle menu item selection
          switch (value) {
            case 'new_community':
              // Create new community
              break;
            case 'find_communities':
              // Find communities
              break;
            case 'community_guidelines':
              // Show guidelines
              break;
            case 'settings':
              // Navigate to settings
              break;
          }
        },
        itemBuilder: (BuildContext context) => <PopupMenuEntry<String>>[
          const PopupMenuItem<String>(
            value: 'new_community',
            child: Row(
              children: [
                Icon(Icons.add_circle_outline, color: Colors.grey),
                SizedBox(width: 12),
                Text('New community'),
              ],
            ),
          ),
          const PopupMenuItem<String>(
            value: 'find_communities',
            child: Row(
              children: [
                Icon(Icons.search, color: Colors.grey),
                SizedBox(width: 12),
                Text('Find communities'),
              ],
            ),
          ),
          const PopupMenuItem<String>(
            value: 'community_guidelines',
            child: Row(
              children: [
                Icon(Icons.description_outlined, color: Colors.grey),
                SizedBox(width: 12),
                Text('Community guidelines'),
              ],
            ),
          ),
          const PopupMenuDivider(),
          const PopupMenuItem<String>(
            value: 'settings',
            child: Row(
              children: [
                Icon(Icons.settings, color: Colors.grey),
                SizedBox(width: 12),
                Text('Settings'),
              ],
            ),
          ),
        ],
      ),
    ],
  );
}