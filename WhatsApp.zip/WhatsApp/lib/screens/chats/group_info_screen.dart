import 'package:flutter/material.dart';
import 'package:whatsapp_clone/constants/colors.dart';
import 'package:whatsapp_clone/models/users.dart';
import 'package:whatsapp_clone/screens/chats/group_members_screen.dart';
import 'package:whatsapp_clone/models/group_avatar_manager.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import 'dart:io' show Platform, File;

class GroupInfoScreen extends StatefulWidget {
  final User user;

  const GroupInfoScreen({super.key, required this.user});

  @override
  State<GroupInfoScreen> createState() => _GroupInfoScreenState();
}

class _GroupInfoScreenState extends State<GroupInfoScreen> {
  final ImagePicker _picker = ImagePicker();
  String? _selectedGroupImage;

  @override
  void initState() {
    super.initState();
    _loadGroupAvatar();
  }

  Future<void> _loadGroupAvatar() async {
    final savedAvatar = await GroupAvatarManager.getGroupAvatar(widget.user.id);
    if (savedAvatar != null && mounted) {
      // Check if the file still exists
      final file = File(savedAvatar);
      if (await file.exists()) {
        setState(() {
          _selectedGroupImage = savedAvatar;
        });
      } else {
        // File doesn't exist, remove the saved path
        await GroupAvatarManager.removeGroupAvatar(widget.user.id);
      }
    }
  }

  bool get _isGroup => widget.user.id.startsWith('hk_') || widget.user.username.contains('群');

  int get _memberCount {
    // Get actual member count from the group members list
    final members = _getGroupMembers();
    return members.length;
  }

  List<String> _getGroupMembers() {
    switch (widget.user.username) {
      case '家庭群組':
        return ['爺爺', '奶奶', '爸爸', '媽媽', '阿哥', '阿妹', '表妹'];
      case '老友群':
        return ['阿琳', '阿強', '阿輝'];
      case '女生群':
        return ['阿琳', '阿婷', '鄰居陳太', '書記', '阿美', '阿芳', '阿圓', '阿彩', 'Jenny', 'Virg'];
      default:
        return [];
    }
  }

  Future<void> _pickGroupImage() async {
    // On iOS, request Photos permission explicitly. On Android, let image_picker handle it.
    if (Platform.isIOS) {
      PermissionStatus status = await Permission.photos.status;
      if (status.isDenied || status.isRestricted) {
        status = await Permission.photos.request();
      }
      if (status.isPermanentlyDenied) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('Permission required to access gallery'),
            backgroundColor: Colors.orange,
            action: SnackBarAction(
              label: 'Open Settings',
              onPressed: openAppSettings,
            ),
          ),
        );
        return;
      }
      if (!status.isGranted) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Permission required to access gallery'),
            backgroundColor: Colors.orange,
          ),
        );
        return;
      }
    }

    try {
      final XFile? image = await _picker.pickImage(
        source: ImageSource.gallery,
        maxWidth: 1024,
        maxHeight: 1024,
        imageQuality: 85,
      );

      if (image != null) {
        setState(() {
          _selectedGroupImage = image.path;
        });

        // Save the group avatar persistently
        await GroupAvatarManager.saveGroupAvatar(widget.user.id, image.path);

        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Group photo updated successfully!'),
            backgroundColor: Colors.green,
            duration: Duration(seconds: 2),
          ),
        );
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error picking image: ${e.toString()}'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.transparent,
        scrolledUnderElevation: 0,
        iconTheme: const IconThemeData(color: kTextColor),
        centerTitle: false,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        padding: const EdgeInsets.only(top: 0.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Centered group photo
            Center(
              child: Column(
                children: [
                  GestureDetector(
                    onTap: _isGroup ? _pickGroupImage : null,
                    child: Stack(
                      children: [
                        CircleAvatar(
                          radius: 65, // 30% larger than original 50
                          backgroundImage: _selectedGroupImage != null
                            ? FileImage(File(_selectedGroupImage!))
                            : AssetImage(widget.user.profilePicture) as ImageProvider,
                        ),
                        if (_isGroup)
                          Positioned(
                            bottom: 0,
                            right: 0,
                            child: Container(
                              width: 30,
                              height: 30,
                              decoration: BoxDecoration(
                                color: kPrimaryColor,
                                shape: BoxShape.circle,
                                border: Border.all(color: Colors.white, width: 2),
                              ),
                              child: const Icon(
                                Icons.camera_alt,
                                color: Colors.white,
                                size: 16,
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    widget.user.username,
                    style: const TextStyle(
                      fontSize: 25,
                      fontWeight: FontWeight.w500,
                      color: kTextColor,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    _isGroup ? '$_memberCount members' : '1:1 chat',
                    style: const TextStyle(color: kTextDarkColor),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
            const SizedBox(height:25),
            LayoutBuilder(
              builder: (context, constraints) {
                return Container(
                  width: constraints.maxWidth,
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      _ActionButton(icon: Icons.call_outlined, label: 'Audio', onTap: () {}),
                      _ActionButton(icon: Icons.videocam_outlined, label: 'Video', onTap: () {}),
                      _ActionButton(icon: Icons.group_add_outlined, label: 'Add', onTap: () {}),
                      _ActionButton(icon: Icons.search_outlined, label: 'Search', onTap: () {}),
                    ],
                  ),
                );
              },
            ),
            const SizedBox(height: 16),
            const Divider(height: 1, thickness: 1),
            Card(
              elevation: 0,
              color: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: kDividerColor.withValues(alpha: .5))),
              child: ListTile(
                leading: const Icon(Icons.description_outlined, color: Colors.black, size: 19),
                title: const Text('Add group description', style: TextStyle(color: kTextColor)),
                trailing: null,
                onTap: () {},
              ),
            ),
            const SizedBox(height: 1),
            // Group Members section
            if (_isGroup) ...[
              Card(
                elevation: 0,
                color: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: kDividerColor.withValues(alpha: .5))),
                child: ListTile(
                  leading: const Icon(Icons.people, color: Colors.black, size: 19),
                  title: const Text('Group Members', style: TextStyle(color: kTextColor)),
                  subtitle: Text('$_memberCount members', style: const TextStyle(color: kTextDarkColor)),
                  trailing: null,
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => GroupMembersScreen(groupUser: widget.user),
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(height: 1),
            ],
            Card(
              elevation: 0,
              color: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: kDividerColor.withValues(alpha: .5))),
              child: ListTile(
                leading: const Icon(Icons.perm_media_outlined, color: Colors.black, size: 19),
                title: const Text('Media, links, and docs', style: TextStyle(color: kTextColor)),
                trailing: null,
                onTap: () {},
              ),
            ),

            // Divider after the 3 cards
            const SizedBox(height: 16),
            const Divider(height: 1, thickness: 1),
            const SizedBox(height: 16),

            // New cards section
            Card(
              elevation: 0,
              color: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: kDividerColor.withValues(alpha: .5))),
              child: ListTile(
                leading: const Icon(Icons.notifications_outlined, color: Colors.black, size: 19),
                title: const Text('Notifications', style: TextStyle(color: kTextColor)),
                subtitle: const Text('All', style: TextStyle(color: kTextDarkColor)),
                trailing: null,
                onTap: () {},
              ),
            ),
            const SizedBox(height: 1),
            Card(
              elevation: 0,
              color: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: kDividerColor.withValues(alpha: .5))),
              child: ListTile(
                leading: const Icon(Icons.image_outlined, color: Colors.black, size: 19),
                title: const Text('Media Visibility', style: TextStyle(color: kTextColor)),
                subtitle: const Text('Off', style: TextStyle(color: kTextDarkColor)),
                trailing: null,
                onTap: () {},
              ),
            ),
            const SizedBox(height: 1),
            Card(
              elevation: 0,
              color: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: kDividerColor.withValues(alpha: .5))),
              child: ListTile(
                leading: const Icon(Icons.lock_outline, color: Colors.black87),
                title: const Text('Encryption', style: TextStyle(color: kTextColor)),
                subtitle: const Text(
                  'Messages and calls are end-to-end encrypted. Tap to learn more',
                  style: TextStyle(color: kTextDarkColor, fontSize: 12),
                ),
                trailing: null,
                onTap: () {},
              ),
            ),
            const SizedBox(height: 1),
            Card(
              elevation: 0,
              color: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: kDividerColor.withValues(alpha: .5))),
              child: ListTile(
                leading: const Icon(Icons.hourglass_bottom, color: Color.fromARGB(255, 0, 0, 0)),
                title: const Text('Disappearing message', style: TextStyle(color: kTextColor)),
                trailing: null,
                onTap: () {},
              ),
            ),
            const SizedBox(height: 1),
            Card(
              elevation: 0,
              color: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: kDividerColor.withValues(alpha: .5))),
              child: ListTile(
                leading: const Icon(Icons.lock_outline, color: Color.fromARGB(255, 0, 0, 0)),
                title: const Text('Chat Lock', style: TextStyle(color: kTextColor)),
                trailing: null,
                onTap: () {},
              ),
            ),
            const SizedBox(height: 1),
            Card(
              elevation: 0,
              color: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: kDividerColor.withValues(alpha: .5))),
              child: ListTile(
                leading: const Icon(Icons.privacy_tip_outlined, color: Color.fromARGB(255, 0, 0, 0)),
                title: const Text('Advanced chat privacy', style: TextStyle(color: kTextColor)),
                trailing: null,
                onTap: () {},
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ActionButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  const _ActionButton({required this.icon, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: SizedBox(
        width: 80,
        height: 70,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(icon, color: kAppBarColor, size: 20),
            ),
            const SizedBox(height: 4),
            Text(
              label,
              style: const TextStyle(color: kTextDarkColor, fontSize: 11),
              textAlign: TextAlign.center,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }
}


