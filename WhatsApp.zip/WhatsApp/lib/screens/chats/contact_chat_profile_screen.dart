import 'package:flutter/material.dart';
import 'package:whatsapp_clone/constants/colors.dart';
import 'package:whatsapp_clone/models/users.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import 'dart:io' show Platform, File;

class ContactChatProfileScreen extends StatefulWidget {
  final User contact;

  const ContactChatProfileScreen({Key? key, required this.contact}) : super(key: key);

  @override
  _ContactChatProfileScreenState createState() => _ContactChatProfileScreenState();
}

class _ContactChatProfileScreenState extends State<ContactChatProfileScreen> {
  final ImagePicker _picker = ImagePicker();
  String? _selectedContactImage;

  Future<void> _pickContactImage() async {
    // On iOS, request Photos permission explicitly. On Android, let image_picker handle it.
    if (Platform.isIOS) {
      PermissionStatus status = await Permission.photos.status;
      if (status.isDenied || status.isRestricted) {
        status = await Permission.photos.request();
      }
      if (status.isPermanentlyDenied) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('Permission required to access gallery'),
            backgroundColor: Colors.orange,
            action: SnackBarAction(
              label: 'Open Settings',
              onPressed: openAppSettings,
            ),
          ),
        );
        return;
      }
      if (!status.isGranted) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Permission required to access gallery'),
            backgroundColor: Colors.orange,
          ),
        );
        return;
      }
    }

    try {
      final XFile? image = await _picker.pickImage(
        source: ImageSource.gallery,
        maxWidth: 1024,
        maxHeight: 1024,
        imageQuality: 85,
      );

      if (image != null) {
        setState(() {
          _selectedContactImage = image.path;
        });

        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Contact photo updated successfully!'),
            backgroundColor: Colors.green,
            duration: Duration(seconds: 2),
          ),
        );
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error picking image: ${e.toString()}'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.transparent,
        scrolledUnderElevation: 0,
        iconTheme: const IconThemeData(color: kTextColor),
        centerTitle: false,
      ),
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        padding: const EdgeInsets.only(top: 8.0, left: 16.0, right: 16.0, bottom: 16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            // Contact photo
            Center(
              child: Column(
                children: [
                  GestureDetector(
                    onTap: _pickContactImage,
                    child: Stack(
                      children: [
                        CircleAvatar(
                          radius: 65,
                          backgroundImage: _selectedContactImage != null
                            ? FileImage(File(_selectedContactImage!))
                            : AssetImage(widget.contact.profilePicture) as ImageProvider,
                        ),
                        Positioned(
                          bottom: 0,
                          right: 0,
                          child: Container(
                            width: 30,
                            height: 30,
                            decoration: BoxDecoration(
                              color: kPrimaryColor,
                              shape: BoxShape.circle,
                              border: Border.all(color: Colors.white, width: 2),
                            ),
                            child: const Icon(
                              Icons.camera_alt,
                              color: Colors.white,
                              size: 16,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    widget.contact.username,
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w600,
                      color: kTextColor,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 8),
                  Builder(
                    builder: (context) {
                      final hashString = widget.contact.id.hashCode.toString();
                      final firstPart = hashString.length >= 4 ? hashString.substring(0, 4) : hashString.padRight(4, '0');
                      final secondPart = hashString.length >= 8 ? hashString.substring(4, 8) : hashString.padRight(8, '0').substring(4, 8);
                      return Text(
                        '+852 $firstPart $secondPart',
                        style: const TextStyle(
                          color: kTextDarkColor,
                          fontSize: 16,
                        ),
                      );
                    },
                  ),
                  const SizedBox(height: 24),
                ],
              ),
            ),

            // Action buttons
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Expanded(
                  child: _ProfileActionButton(
                    icon: Icons.call,
                    label: 'Audio',
                    onTap: () {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Audio call feature coming soon')),
                      );
                    },
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _ProfileActionButton(
                    icon: Icons.videocam,
                    label: 'Video',
                    onTap: () {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Video call feature coming soon')),
                      );
                    },
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _ProfileActionButton(
                    icon: Icons.search,
                    label: 'Search',
                    onTap: () {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Search feature coming soon')),
                      );
                    },
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),

            // About section
            Card(
              elevation: 0,
              color: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
                side: BorderSide(color: kDividerColor.withValues(alpha: 0.5))
              ),
              child: const Padding(
                padding: EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'About',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w500,
                        color: kTextColor,
                      ),
                    ),
                    SizedBox(height: 8),
                    Text(
                      'Hey there! I\'m using WhatsApp.',
                      style: TextStyle(
                        color: kTextDarkColor,
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 1),

            // Media, links, and docs section
            Card(
              elevation: 0,
              color: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
                side: BorderSide(color: kDividerColor.withValues(alpha: 0.5))
              ),
              child: ListTile(
                leading: const Icon(Icons.perm_media_outlined, color: Colors.black),
                title: const Text('Media, links, and docs', style: TextStyle(color: kTextColor)),
                trailing: null,
                onTap: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Media feature coming soon')),
                  );
                },
              ),
            ),

            // Divider after the 3 cards
            const SizedBox(height: 16),
            const Divider(height: 1, thickness: 1),
            const SizedBox(height: 16),

            // New cards section
            Card(
              elevation: 0,
              color: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
                side: BorderSide(color: kDividerColor.withValues(alpha: 0.5))
              ),
              child: ListTile(
                leading: const Icon(Icons.notifications_outlined, color: Colors.black),
                title: const Text('Notifications', style: TextStyle(color: kTextColor)),
                subtitle: const Text('All', style: TextStyle(color: kTextDarkColor)),
                trailing: null,
                onTap: () {},
              ),
            ),
            const SizedBox(height: 1),
            Card(
              elevation: 0,
              color: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
                side: BorderSide(color: kDividerColor.withValues(alpha: 0.5))
              ),
              child: ListTile(
                leading: const Icon(Icons.visibility_outlined, color: Colors.black),
                title: const Text('Media Visibility', style: TextStyle(color: kTextColor)),
                subtitle: const Text('Off', style: TextStyle(color: kTextDarkColor)),
                trailing: null,
                onTap: () {},
              ),
            ),
            const SizedBox(height: 1),
            Card(
              elevation: 0,
              color: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
                side: BorderSide(color: kDividerColor.withValues(alpha: 0.5))
              ),
              child: ListTile(
                leading: const Icon(Icons.lock_outlined, color: Colors.black),
                title: const Text('Encryption', style: TextStyle(color: kTextColor)),
                subtitle: const Text(
                  'Messages and calls are end-to-end encrypted. Tap to learn more',
                  style: TextStyle(color: kTextDarkColor, fontSize: 12),
                ),
                trailing: null,
                onTap: () {},
              ),
            ),
            const SizedBox(height: 1),
            Card(
              elevation: 0,
              color: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
                side: BorderSide(color: kDividerColor.withValues(alpha: 0.5))
              ),
              child: ListTile(
                leading: const Icon(Icons.timer_outlined, color: Colors.black),
                title: const Text('Disappearing message', style: TextStyle(color: kTextColor)),
                trailing: null,
                onTap: () {},
              ),
            ),
            const SizedBox(height: 1),
            Card(
              elevation: 0,
              color: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
                side: BorderSide(color: kDividerColor.withValues(alpha: 0.5))
              ),
              child: ListTile(
                leading: const Icon(Icons.lock_outline, color: Colors.black),
                title: const Text('Chat Lock', style: TextStyle(color: kTextColor)),
                trailing: null,
                onTap: () {},
              ),
            ),
            const SizedBox(height: 1),
            Card(
              elevation: 0,
              color: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
                side: BorderSide(color: kDividerColor.withValues(alpha: 0.5))
              ),
              child: ListTile(
                leading: const Icon(Icons.privacy_tip_outlined, color: Colors.black),
                title: const Text('Advanced chat privacy', style: TextStyle(color: kTextColor)),
                trailing: null,
                onTap: () {},
              ),
            ),

            // Divider before Block contact
            const SizedBox(height: 16),
            const Divider(height: 1, thickness: 1),
            const SizedBox(height: 16),

            // Block contact section
            Card(
              elevation: 0,
              color: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
                side: BorderSide(color: kDividerColor.withValues(alpha: 0.5))
              ),
              child: ListTile(
                leading: const Icon(Icons.block, color: Colors.red),
                title: const Text('Block contact', style: TextStyle(color: Colors.red)),
                onTap: () {
                  showDialog(
                    context: context,
                    builder: (context) => AlertDialog(
                      title: const Text('Block Contact'),
                      content: Text('Are you sure you want to block ${widget.contact.username}?'),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.pop(context),
                          child: const Text('Cancel'),
                        ),
                        TextButton(
                          onPressed: () {
                            Navigator.pop(context);
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(content: Text('${widget.contact.username} has been blocked')),
                            );
                          },
                          child: const Text('Block', style: TextStyle(color: Colors.red)),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ProfileActionButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  const _ProfileActionButton({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: SizedBox(
        width: 120,
        height: 65,
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 12),
              decoration: BoxDecoration(
                color: Colors.white,
                border: Border.all(color: Colors.grey, width: 1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: kAppBarColor, size: 22),
            ),
            const SizedBox(height: 4),
            Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: kTextDarkColor,
                fontSize: 12,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
