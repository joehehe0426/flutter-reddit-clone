import 'package:flutter/material.dart';
import 'package:whatsapp_clone/constants/colors.dart';
import 'package:whatsapp_clone/models/users.dart';
import 'package:whatsapp_clone/screens/contacts/models/contact_manager.dart';
import 'package:whatsapp_clone/models/hk_mock_history.dart';

class GroupMembersScreen extends StatelessWidget {
  final User groupUser;

  const GroupMembersScreen({super.key, required this.groupUser});

  // Get group members based on group name
  List<String> _getGroupMembers() {
    switch (groupUser.username) {
      case '家庭群組':
        return characters.sublist(0, 7); // Family members
      case '老友群':
        return ["阿琳", "阿強", "阿輝"]; // Friends group
      case '女生群':
        // Girls' names only for girls group
        return ["阿琳", "阿婷", "鄰居陳太", "書記", "阿美", "阿芳", "阿圓", "阿彩", "Jenny", "Virg"];
      default:
        // Try to find members from chat history
        final groupMessages = hkChatHistory.where((msg) =>
          msg.isGroupChat && msg.recipient == groupUser.username
        ).toList();

        if (groupMessages.isNotEmpty) {
          return groupMessages.first.groupMembers ?? [];
        }
        return [];
    }
  }

  // Get user by name from contacts
  User? _getUserByName(String name) {
    // First try to find in users list
    final user = users.firstWhere(
      (user) => user.username == name,
      orElse: () => User(
        id: 'unknown',
        username: name,
        profilePicture: 'assets/img/dps/default.jpg'
      )
    );

    // If found a valid user, return it
    if (user.id != 'unknown') {
      return user;
    }

    // Try to find in contact manager
    final contact = ContactManager.getContact(name);
    if (contact != null) {
      return User(
        id: contact.id,
        username: contact.name,
        profilePicture: contact.avatarPath ?? 'assets/img/dps/default.jpg'
      );
    }

    return null;
  }

  // Get color for member name (same as in chat bubbles)
  Color _getColorForName(String name) {
    int hash = 0;
    for (int i = 0; i < name.length; i++) {
      hash = (hash * 31 + name.codeUnitAt(i)) & 0x7fffffff;
    }
    final double hue = (hash % 360).toDouble();
    return HSLColor.fromAHSL(1.0, hue, 0.70, 0.50).toColor();
  }

  @override
  Widget build(BuildContext context) {
    final members = _getGroupMembers();

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.transparent,
        scrolledUnderElevation: 0,
        title: Text(
          '${members.length} members',
          style: const TextStyle(color: kTextColor),
        ),
        iconTheme: const IconThemeData(color: kTextColor),
        centerTitle: false,
      ),
      backgroundColor: Colors.white,
      body: ListView.builder(
        itemCount: members.length,
        itemBuilder: (context, index) {
          final memberName = members[index];
          final user = _getUserByName(memberName);

          return Card(
            margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            elevation: 0,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
              side: BorderSide(color: kDividerColor.withValues(alpha: 0.5))
            ),
            child: ListTile(
              leading: CircleAvatar(
                radius: 24,
                backgroundColor: _getColorForName(memberName),
                child: Text(
                  memberName.isNotEmpty ? memberName[0] : '?',
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
              ),
              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              isThreeLine: false,
              title: Text(
                memberName,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: kTextColor,
                  fontWeight: FontWeight.w500,
                ),
              ),
              subtitle: Text(
                '點擊查看個人資料',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(color: kTextDarkColor, fontSize: 12),
              ),
              onTap: () {
                if (user != null) {
                  _showMemberProfile(context, user, memberName);
                } else {
                  // Show snackbar if user not found
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Profile for $memberName not available'),
                      backgroundColor: Colors.grey,
                    ),
                  );
                }
              },
            ),
          );
        },
      ),
    );
  }

  void _showMemberProfile(BuildContext context, User user, String memberName) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.6,
        maxChildSize: 0.9,
        minChildSize: 0.4,
        builder: (context, scrollController) => SingleChildScrollView(
          controller: scrollController,
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // Profile picture
              CircleAvatar(
                radius: 60,
                backgroundColor: _getColorForName(memberName),
                child: Text(
                  memberName.isNotEmpty ? memberName[0] : '?',
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 32,
                  ),
                ),
              ),
              const SizedBox(height: 20),

              // Name
              Text(
                memberName,
                style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w600,
                  color: kTextColor,
                ),
              ),
              const SizedBox(height: 8),

              // Phone number (generated)
              Builder(
                builder: (context) {
                  final hashString = user.id.hashCode.toString();
                  final firstPart = hashString.length >= 4 ? hashString.substring(0, 4) : hashString.padRight(4, '0');
                  final secondPart = hashString.length >= 8 ? hashString.substring(4, 8) : hashString.padRight(8, '0').substring(4, 8);
                  return Text(
                    '+852 $firstPart $secondPart',
                    style: const TextStyle(
                      color: kTextDarkColor,
                      fontSize: 16,
                    ),
                  );
                },
              ),
              const SizedBox(height: 24),

              // Action buttons
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Expanded(
                    child: _ProfileActionButton(
                      icon: Icons.call,
                      label: 'Audio',
                      onTap: () {
                        Navigator.pop(context);
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Audio call feature coming soon')),
                        );
                      },
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _ProfileActionButton(
                      icon: Icons.videocam,
                      label: 'Video',
                      onTap: () {
                        Navigator.pop(context);
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Video call feature coming soon')),
                        );
                      },
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _ProfileActionButton(
                      icon: Icons.message,
                      label: 'Message',
                      onTap: () {
                        Navigator.pop(context);
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text('Start chat with $memberName')),
                        );
                      },
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 24),

              // Bio section
              Card(
                elevation: 0,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                  side: BorderSide(color: kDividerColor.withValues(alpha: 0.5))
                ),
                child: const Padding(
                  padding: EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'About',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: kTextColor,
                        ),
                      ),
                      SizedBox(height: 8),
                      Text(
                        'Hey there! I\'m using WhatsApp.',
                        style: TextStyle(
                          color: kTextDarkColor,
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              // Close button
              const SizedBox(height: 20),
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text(
                  'Close',
                  style: TextStyle(color: kPrimaryColor),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ProfileActionButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  const _ProfileActionButton({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: ConstrainedBox(
        constraints: const BoxConstraints(minHeight: 68),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container
            (
              padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
              decoration: BoxDecoration(
                color: Colors.white,
                border: Border.all(color: Colors.grey, width: 1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: kAppBarColor, size: 22),
            ),
            const SizedBox(height: 4),
            Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              softWrap: false,
              style: const TextStyle(
                color: kTextDarkColor,
                fontSize: 12,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
