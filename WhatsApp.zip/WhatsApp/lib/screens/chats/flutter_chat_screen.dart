import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter_chat_core/flutter_chat_core.dart';
import 'package:flutter_chat_ui/flutter_chat_ui.dart';
import 'package:whatsapp_clone/constants/colors.dart';

class FlutterChatScreen extends StatefulWidget {
  final String userId;
  
  const FlutterChatScreen({super.key, required this.userId});

  @override
  State<FlutterChatScreen> createState() => _FlutterChatScreenState();
}

class _FlutterChatScreenState extends State<FlutterChatScreen> {
  final _chatController = InMemoryChatController();
  final _botId = 'bot_user';

  @override
  void initState() {
    super.initState();
    // Add initial bot message
    _addBotMessage('Hello! I\'m your chat assistant. How can I help you today?');
  }

  Future<void> _addBotMessage(String text) async {
    await _chatController.insertMessage(
      TextMessage(
        id: '${Random().nextInt(10000) + 1}',
        authorId: _botId,
        createdAt: DateTime.now().toUtc(),
        text: text,
      ),
    );
  }

  Future<void> _handleBotReply(String userMessage) async {
    // Simple bot responses
    String botReply = '';
    final lowerMessage = userMessage.toLowerCase();
    
    if (lowerMessage.contains('hello') || lowerMessage.contains('hi')) {
      botReply = 'Hello there! Nice to meet you! 👋';
    } else if (lowerMessage.contains('how are you')) {
      botReply = 'I\'m doing great, thanks for asking! How about you? 😊';
    } else if (lowerMessage.contains('bye') || lowerMessage.contains('goodbye')) {
      botReply = 'Goodbye! Have a wonderful day! 👋';
    } else if (lowerMessage.contains('help')) {
      botReply = 'I can help you with basic conversation. Try saying hello, asking how I am, or just chat with me! 💬';
    } else if (lowerMessage.contains('weather')) {
      botReply = 'I\'m sorry, I don\'t have access to weather information yet. But I\'m happy to chat! ☀️';
    } else if (lowerMessage.contains('name')) {
      botReply = 'My name is ChatBot! What\'s your name? 🤖';
    } else {
      // Random responses for other messages
      final responses = [
        'That\'s interesting! Tell me more about that.',
        'I see what you mean. Can you elaborate?',
        'Thanks for sharing that with me!',
        'That\'s a great point!',
        'I\'m learning from our conversation!',
        'Keep talking, I\'m listening! 👂',
      ];
      botReply = responses[Random().nextInt(responses.length)];
    }
    
    // Add bot reply immediately
    await _addBotMessage(botReply);
  }

  @override
  void dispose() {
    _chatController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.transparent,
        scrolledUnderElevation: 0,
        title: Text(
          'Chat with Bot',
          style: const TextStyle(color: kTextColor),
        ),
        iconTheme: const IconThemeData(color: kTextColor),
      ),
      body: Chat(
        chatController: _chatController,
        currentUserId: widget.userId,
        onMessageSend: (text) async {
          await _chatController.insertMessage(
            TextMessage(
              id: '${Random().nextInt(10000) + 1}',
              authorId: widget.userId,
              createdAt: DateTime.now().toUtc(),
              text: text,
            ),
          );
          // Trigger bot reply
          await _handleBotReply(text);
        },
        resolveUser: (UserID id) async {
          if (id == _botId) {
            return User(id: id, name: 'ChatBot');
          }
          return User(id: id, name: 'You');
        },

      ),
    );
  }

  // 🎨 Custom Message Bubble
  Widget _buildCustomMessageBubble(TextMessage message) {
    final isFromUser = message.authorId == widget.userId;
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
      child: Row(
        mainAxisAlignment: isFromUser ? MainAxisAlignment.end : MainAxisAlignment.start,
        children: [
          if (!isFromUser) ...[
            _buildCustomAvatar(User(id: _botId, name: 'ChatBot')),
            const SizedBox(width: 8),
          ],
          Flexible(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              decoration: BoxDecoration(
                color: isFromUser ? const Color(0xFF25D366) : Colors.white,
                borderRadius: BorderRadius.circular(18),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.1),
                    blurRadius: 4,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (!isFromUser)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 4),
                      child: Text(
                        'ChatBot',
                        style: TextStyle(
                          color: const Color(0xFF25D366),
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  Text(
                    message.text,
                    style: TextStyle(
                      color: isFromUser ? Colors.white : const Color(0xFF1C1E21),
                      fontSize: 16,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    _formatTime(message.createdAt),
                    style: TextStyle(
                      color: isFromUser ? Colors.white70 : const Color(0xFF65676B),
                      fontSize: 11,
                    ),
                  ),
                ],
              ),
            ),
          ),
          if (isFromUser) ...[
            const SizedBox(width: 8),
            _buildCustomAvatar(User(id: widget.userId, name: 'You')),
          ],
        ],
      ),
    );
  }

  // 🎨 Custom Input Area
  Widget _buildCustomInput(Function(String) onSendPressed) {
    final textController = TextEditingController();
    
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.1),
            blurRadius: 8,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: Row(
        children: [
          Expanded(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: const Color(0xFFF0F2F5),
                borderRadius: BorderRadius.circular(24),
                border: Border.all(
                  color: const Color(0xFF25D366).withValues(alpha: 0.3),
                ),
              ),
              child: TextField(
                controller: textController,
                decoration: const InputDecoration(
                  hintText: 'Type a message...',
                  border: InputBorder.none,
                  hintStyle: TextStyle(
                    color: Color(0xFF65676B),
                    fontSize: 16,
                  ),
                ),
                style: const TextStyle(
                  color: Color(0xFF1C1E21),
                  fontSize: 16,
                ),
                onSubmitted: (text) {
                  if (text.isNotEmpty) {
                    onSendPressed(text);
                    textController.clear();
                  }
                },
              ),
            ),
          ),
          const SizedBox(width: 8),
          Container(
            decoration: const BoxDecoration(
              color: Color(0xFF25D366),
              shape: BoxShape.circle,
            ),
            child: IconButton(
              onPressed: () {
                if (textController.text.isNotEmpty) {
                  onSendPressed(textController.text);
                  textController.clear();
                }
              },
              icon: const Icon(
                Icons.send,
                color: Colors.white,
                size: 20,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // 🎨 Custom Avatar
  Widget _buildCustomAvatar(User user) {
    final isBot = user.id == _botId;
    final isUser = user.id == widget.userId;
    
    Color avatarColor;
    String avatarText;
    
    if (isBot) {
      avatarColor = const Color(0xFF25D366);
      avatarText = 'B';
    } else if (isUser) {
      avatarColor = const Color(0xFF1E88E5);
      avatarText = 'Y';
    } else {
      avatarColor = const Color(0xFFD81B60);
      avatarText = (user.name?.isNotEmpty == true) ? user.name![0].toUpperCase() : '?';
    }
    
    return CircleAvatar(
      radius: 16,
      backgroundColor: avatarColor,
      child: Text(
        avatarText,
        style: const TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.bold,
          fontSize: 12,
        ),
      ),
    );
  }

  String _formatTime(DateTime? time) {
    if (time == null) return '';
    final now = DateTime.now();
    final difference = now.difference(time);
    
    if (difference.inDays > 0) {
      return '${difference.inDays}d';
    } else if (difference.inHours > 0) {
      return '${difference.inHours}h';
    } else if (difference.inMinutes > 0) {
      return '${difference.inMinutes}m';
    } else {
      return 'now';
    }
  }
}
