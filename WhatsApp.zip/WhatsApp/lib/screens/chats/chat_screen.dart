import 'package:flutter/material.dart';
import 'package:whatsapp_clone/screens/chats/components/chat_screen_body.dart';
import 'package:whatsapp_clone/screens/chats/components/widgets/chat_screen/chat_screen_appbar.dart';
import 'package:whatsapp_clone/models/users.dart';

class ChatScreen extends StatelessWidget {
  static String routeName = '/chat-screen';
  final String? userId;
  const ChatScreen({super.key, this.userId});

  @override
  Widget build(BuildContext context) {
    final user = users.firstWhere(
      (u) => u.id == userId,
      orElse: () => users.first, // Fallback to first user if not found
    );
    final resolvedUserId = user.id; // ensure we always pass a valid id
    return Scaffold(
      appBar: ChatScreenAppBar(user: user),
      body: ChatScreenBody(userId: resolvedUserId),
    );
  }
}
