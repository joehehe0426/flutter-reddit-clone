import 'package:flutter/material.dart';
import 'package:whatsapp_clone/screens/chats/components/widgets/chat_messages.dart';
import 'package:whatsapp_clone/screens/chats/components/widgets/chat_screen/send_msg_record_audio.dart';
// removed unused colors import



import 'package:whatsapp_clone/models/messages.dart';

class ChatScreenBody extends StatelessWidget {
  final String? userId;
  const ChatScreenBody({
    super.key,
    this.userId,
  });

  @override
  Widget build(BuildContext context) {
    final messages = userId != null ? (userChatHistories[userId] ?? []) : [];
    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        image: DecorationImage(
          fit: BoxFit.cover,
          image: AssetImage('assets/img/chat_bg_light.png'),
        ),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          ChatScreenMessagesWidget(inboxMessages: messages.cast<ChatMessage>()),
          const SafeArea(
            child: SendMessageAndRecordAudioWidget(),
          ),
        ],
      ),
    );
  }
}