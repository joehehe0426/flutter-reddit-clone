import 'package:flutter/material.dart';
import 'package:whatsapp_clone/models/messages.dart';
import 'package:whatsapp_clone/screens/chats/components/widgets/messages/receiver_message_bubble.dart';
import 'package:whatsapp_clone/screens/chats/components/widgets/messages/sender_message_bubble.dart';
import 'package:intl/intl.dart';

class ChatScreenMessagesWidget extends StatelessWidget {
  final List<ChatMessage> inboxMessages;

  const ChatScreenMessagesWidget({
    super.key,
    required this.inboxMessages,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: ListView.builder(
        itemCount: inboxMessages.length,
        itemBuilder: (context, index) {
          final currentMsg = inboxMessages[index];
          final prevMsg = index > 0 ? inboxMessages[index - 1] : null;
          final currentDate = currentMsg.date;
          final prevDate = prevMsg?.date ?? '';
          final showDateHeader = prevMsg == null || currentDate != prevDate;

          List<Widget> widgets = [];
          if (showDateHeader && currentDate.isNotEmpty) {
            widgets.add(
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 8.0),
                child: Center(
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                    decoration: BoxDecoration(
                      color: Colors.grey.shade300,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      _formatDate(currentDate),
                      style: const TextStyle(fontSize: 12, color: Colors.black54),
                    ),
                  ),
                ),
              ),
            );
          }
          if (!currentMsg.isSender) {
            widgets.add(ReceiverMessageBubble(
              message: currentMsg.message,
              timeStamp: currentMsg.timeStamp,
              senderName: currentMsg.senderName,
              imageAsset: currentMsg.imageAsset,
              fileAsset: currentMsg.fileAsset,
            ));
          } else {
            widgets.add(SenderMessageBubble(
              message: currentMsg.message,
              timeStamp: currentMsg.timeStamp,
              imageAsset: currentMsg.imageAsset,
              fileAsset: currentMsg.fileAsset,
            ));
          }
          return Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: widgets,
          );
        },
      ),
    );
  }

  String _formatDate(String date) {
    final now = DateTime.now();
    final msgDate = DateTime.tryParse(date);
    
    if (msgDate != null) {
      if (msgDate.year == now.year && msgDate.month == now.month && msgDate.day == now.day) {
        return 'Today';
      }
      final yesterday = now.subtract(const Duration(days: 1));
      if (msgDate.year == yesterday.year && msgDate.month == yesterday.month && msgDate.day == yesterday.day) {
        return 'Yesterday';
      }
      return DateFormat('MMM d').format(msgDate);
    }
    return date;
  }
}
