import 'package:flutter/material.dart';
import 'package:whatsapp_clone/constants/colors.dart';
import 'package:whatsapp_clone/models/users.dart';
import 'package:whatsapp_clone/screens/chats/group_info_screen.dart';
import 'package:whatsapp_clone/screens/chats/contact_chat_profile_screen.dart';
import 'package:whatsapp_clone/models/group_avatar_manager.dart';
import 'dart:io';


class ChatScreenAppBar extends StatefulWidget implements PreferredSizeWidget {
  final User user;

  const ChatScreenAppBar({super.key, required this.user});

  @override
  State<ChatScreenAppBar> createState() => _ChatScreenAppBarState();

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);
}

class _ChatScreenAppBarState extends State<ChatScreenAppBar> {
  String? _groupAvatarPath;

  @override
  void initState() {
    super.initState();
    _loadGroupAvatar();
  }

  Future<void> _loadGroupAvatar() async {
    if (widget.user.id.startsWith('hk_') || widget.user.username.contains('群')) {
      final savedAvatar = await GroupAvatarManager.getGroupAvatar(widget.user.id);
      if (savedAvatar != null && mounted) {
        // Check if the file still exists
        final file = File(savedAvatar);
        if (await file.exists()) {
          setState(() {
            _groupAvatarPath = savedAvatar;
          });
        } else {
          // File doesn't exist, remove the saved path
          await GroupAvatarManager.removeGroupAvatar(widget.user.id);
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return AppBar(
      backgroundColor: Colors.white,
      surfaceTintColor: Colors.transparent,
      scrolledUnderElevation: 0,
      centerTitle: false,
      leadingWidth: 35.0,
      title: InkWell(
        onTap: () {
          // Check if it's a group chat or individual chat
          bool isGroup = widget.user.id.startsWith('hk_') || widget.user.username.contains('群');

          if (isGroup) {
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => GroupInfoScreen(user: widget.user),
              ),
            );
          } else {
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => ContactChatProfileScreen(contact: widget.user),
              ),
            );
          }
        },
        borderRadius: BorderRadius.circular(24),
        child: Row(
          children: [
            CircleAvatar(
              backgroundColor: kbackgroundColor,
              backgroundImage: _groupAvatarPath != null
                ? FileImage(File(_groupAvatarPath!))
                : AssetImage(widget.user.profilePicture) as ImageProvider,
            ),
            const SizedBox(width: 10.0),
            Flexible(
              child: Text(
                widget.user.username,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: kTextColor,
                  fontWeight: FontWeight.w500
                ),
              ),
            ),
          ],
        ),
      ),
      actions: [
        IconButton(
          onPressed: () {},
          icon: const Icon(Icons.video_camera_front_outlined),
        ),
        IconButton(
          onPressed: () {},
          icon: const Icon(Icons.phone_outlined),
        ),
        IconButton(
          onPressed: () {},
          icon: const Icon(Icons.more_vert),
        ),
      ],
    );
  }
}
