import 'package:flutter/material.dart';
import 'package:whatsapp_clone/constants/colors.dart';
import 'package:whatsapp_clone/screens/contacts/models/contact_manager.dart';
import 'dart:io';

Color _colorForSender(String name) {
  int hash = 0;
  for (int i = 0; i < name.length; i++) {
    hash = (hash * 31 + name.codeUnitAt(i)) & 0x7fffffff;
  }
  final double hue = (hash % 360).toDouble();
  // Higher saturation for vibrancy, medium lightness for readability
  return HSLColor.fromAHSL(1.0, hue, 0.70, 0.50).toColor();
}


class ReceiverMessageBubble extends StatelessWidget {
  final String message;
  final String timeStamp;
  final String? senderName;
  final String? imageAsset;
  final String? fileAsset;

  const ReceiverMessageBubble({
    super.key,
    required this.message,
    required this.timeStamp,
    this.senderName,
    this.imageAsset,
    this.fileAsset,
  });

  @override
  Widget build(BuildContext context) {
    final String? img = imageAsset;

    return Align(
      alignment: Alignment.centerLeft,
      child: ConstrainedBox(
        constraints: BoxConstraints(
          maxWidth: MediaQuery.of(context).size.width * 0.8, // Use 80% of width
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Profile avatar (ball) with first name initial
            if (senderName != null && senderName!.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(left: 1.0, right: 8.0, top: 1.0),
                child: _buildProfileAvatar(senderName!),
              ),
            // Message bubble
            Expanded(
              child: Card(
                color: kmessageBubbleColor,
                elevation: 1.0,
                margin: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 5.0),
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.only(
                    topRight: Radius.circular(10.0),
                    bottomRight: Radius.circular(10.0),
                    bottomLeft: Radius.circular(10.0),
                  )
                ),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 8.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      if (senderName != null && senderName!.isNotEmpty)
                        Padding(
                          padding: const EdgeInsets.only(bottom: 2.0),
                          child: Text(
                            senderName!,
                            style: TextStyle(
                              color: _colorForSender(senderName!),
                              fontWeight: FontWeight.w600,
                              fontSize: 12.0,
                            ),
                          ),
                        ),
                      if (img != null) ...[
                        ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: Image.asset(
                            img,
                            fit: BoxFit.cover,
                            height: 160,
                          ),
                        ),
                        const SizedBox(height: 6),
                      ],
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Expanded(
                            child: Text(
                              message,
                              style: const TextStyle(color: kTextColor),
                              softWrap: true,
                              maxLines: null,
                            ),
                          ),
                          const SizedBox(width: 8.0),
                          Text(
                            timeStamp,
                            style: const TextStyle(color: kTextDarkColor, fontSize: 12.0),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProfileAvatar(String senderName) {
    // Try to get contact avatar by name first
    final contactByName = ContactManager.getContactByName(senderName);
    final avatarPath = contactByName?.avatarPath;
    
    if (avatarPath != null && avatarPath.isNotEmpty) {
      return CircleAvatar(
        radius: 18.0,
        backgroundImage: FileImage(File(avatarPath)),
      );
    }
    
    // Fallback to colored initial if no avatar
    return CircleAvatar(
      radius: 18.0,
      backgroundColor: _colorForSender(senderName),
      child: Text(
        senderName.isNotEmpty ? senderName[0].toUpperCase() : '?',
        style: const TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.bold,
          fontSize: 14.0,
        ),
      ),
    );
  }
}
