import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:open_filex/open_filex.dart';
import 'package:path_provider/path_provider.dart';
import 'package:whatsapp_clone/constants/colors.dart';


class SenderMessageBubble extends StatelessWidget {
  final String message;
  final String timeStamp;
  final String? imageAsset;
  final String? fileAsset;

  const SenderMessageBubble({
    super.key,
    required this.message,
    required this.timeStamp,
    this.imageAsset,
    this.fileAsset,
  });

  Future<void> _openPdfFromAsset(BuildContext context, String assetPath) async {
    try {
      final bytes = await rootBundle.load(assetPath);
      final dir = await getTemporaryDirectory();
      final file = File('${dir.path}/${assetPath.split('/').last}');
      await file.writeAsBytes(bytes.buffer.asUint8List());
      final result = await OpenFilex.open(file.path);
      if (result.type != ResultType.done) {
        // Fallback toast
        // ignore: use_build_context_synchronously
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('無法開啟檔案: ${result.message}')),
        );
      }
    } catch (e) {
      // ignore: use_build_context_synchronously
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('開啟檔案失敗: $e')),
      );
    }
  }

  void _showZoomImage(BuildContext context, String asset) {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.9),
      builder: (_) {
        final tag = 'img-$asset-$timeStamp';
        return GestureDetector(
          onTap: () => Navigator.of(context).pop(),
          child: Dismissible(
            key: Key(tag),
            direction: DismissDirection.down,
            onDismissed: (_) => Navigator.of(context).pop(),
            child: Center(
              child: Hero(
                tag: tag,
                child: InteractiveViewer(
                  panEnabled: true,
                  minScale: 0.5,
                  maxScale: 4.0,
                  child: Image.asset(asset, fit: BoxFit.contain),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final bool hasText = message.trim().isNotEmpty;
    final String? img = imageAsset;
    final String? pdf = fileAsset;

    return Align(
      alignment: Alignment.centerRight,
      child: ConstrainedBox(
        constraints: BoxConstraints(
          maxWidth: MediaQuery.of(context).size.width * .65,
        ),
        child: Card(
          color: ksenderMessageBubbleColor,
          elevation: 1.0,
          margin: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 5.0),
          shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(10.0),
              bottomRight: Radius.circular(10.0),
              bottomLeft: Radius.circular(10.0),
            )
          ),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 8.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              mainAxisSize: MainAxisSize.min,
              children: [
                if (img != null) ...[
                  GestureDetector(
                    onTap: () => _showZoomImage(context, img),
                    child: Hero(
                      tag: 'img-$img-$timeStamp',
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: Image.asset(
                          img,
                          fit: BoxFit.cover,
                          height: 160,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 6),
                ],
                if (pdf != null) ...[
                  InkWell(
                    onTap: () => _openPdfFromAsset(context, pdf),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        border: Border.all(color: kDividerColor),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.picture_as_pdf, color: Colors.redAccent, size: 18),
                          const SizedBox(width: 8),
                          Flexible(
                            child: Text(
                              pdf.split('/').last,
                              style: const TextStyle(color: kTextColor),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 6),
                ],
                if (hasText)
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Expanded(
                        child: Text(
                          message,
                          style: const TextStyle(color: kTextColor),
                          softWrap: message.length > 30,
                          maxLines: message.length > 30 ? null : 1,
                          overflow: message.length > 30 ? null : TextOverflow.ellipsis,
                        ),
                      ),
                      const SizedBox(width: 4.0),
                      Text(
                        timeStamp,
                        style: const TextStyle(color: kTextDarkColor, fontSize: 12.0),
                      ),
                      const SizedBox(width: 4.0),
                      const Icon(Icons.done_all, color: kBlueTickColor, size: 16.0),
                    ],
                  )
                else
                  Align(
                    alignment: Alignment.centerRight,
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          timeStamp,
                          style: const TextStyle(color: kTextDarkColor, fontSize: 12.0),
                        ),
                        const SizedBox(width: 4.0),
                        const Icon(Icons.done_all, color: kBlueTickColor, size: 16.0),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
