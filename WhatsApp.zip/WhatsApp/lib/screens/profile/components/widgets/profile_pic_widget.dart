import 'package:flutter/material.dart';
import 'package:whatsapp_clone/constants/colors.dart';
import 'package:whatsapp_clone/models/user_profile.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import 'dart:io' show Platform;

class UserProfilePictureWidget extends StatefulWidget {
  const UserProfilePictureWidget({
    super.key,
  });

  @override
  State<UserProfilePictureWidget> createState() => _UserProfilePictureWidgetState();
}

class _UserProfilePictureWidgetState extends State<UserProfilePictureWidget> {
  final ImagePicker _picker = ImagePicker();

  Future<void> _pickImage() async {
    // On iOS, request Photos permission explicitly. On Android, let image_picker handle it.
    if (Platform.isIOS) {
      PermissionStatus status = await Permission.photos.status;
      if (status.isDenied || status.isRestricted) {
        status = await Permission.photos.request();
      }
      if (status.isPermanentlyDenied) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('Permission required to access gallery'),
            backgroundColor: Colors.orange,
            action: SnackBarAction(
              label: 'Open Settings',
              onPressed: openAppSettings,
            ),
          ),
        );
        return;
      }
      if (!status.isGranted) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Permission required to access gallery'),
            backgroundColor: Colors.orange,
          ),
        );
        return;
      }
    }

    try {
      final XFile? image = await _picker.pickImage(
        source: ImageSource.gallery,
        maxWidth: 1024,
        maxHeight: 1024,
        imageQuality: 85,
      );
      if (image != null) {
        setState(() {
          UserProfile.updateProfilePicture(image.path);
        });
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error picking image: ${e.toString()}'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Stack(
        children: [
          UserProfile.getProfileImage(radius: MediaQuery.of(context).size.height * .10),
          Positioned(
            bottom: 0,
            right: 0,
            child: Container(
              decoration: const BoxDecoration(
                color: kPrimaryColor,
                shape: BoxShape.circle,
              ),
              child: IconButton(
                onPressed: _pickImage, 
                icon: const Icon(Icons.camera_alt_outlined, color: Colors.white),
              ),
            ),
          ),
        ],
      ),
    );
  }
}