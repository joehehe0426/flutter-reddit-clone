import 'package:flutter/material.dart';
import 'package:whatsapp_clone/screens/updates/components/body.dart';
import 'package:whatsapp_clone/screens/updates/components/widgets/floating_action_btn.dart';


class UpdatesScreen extends StatelessWidget {
  const UpdatesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: const Text(
          'Updates',
          style: TextStyle(
            fontSize: 20.0,
          ),
        ),
        actions: [
          IconButton(
            onPressed: () {}, 
            icon: const Icon(Icons.camera_alt_outlined),
          ),
          IconButton(
            onPressed: () {}, 
            icon: const Icon(Icons.search_outlined),
          ),
          PopupMenuButton<String>(
            icon: const Icon(Icons.more_vert),
            onSelected: (value) {
              // Handle menu item selection
              switch (value) {
                case 'status_privacy':
                  // Status privacy settings
                  break;
                case 'status_settings':
                  // Status settings
                  break;
                case 'help':
                  // Show help
                  break;
                case 'settings':
                  // Navigate to settings
                  break;
              }
            },
            itemBuilder: (BuildContext context) => <PopupMenuEntry<String>>[
              const PopupMenuItem<String>(
                value: 'status_privacy',
                child: Row(
                  children: [
                    Icon(Icons.privacy_tip_outlined, color: Colors.grey),
                    SizedBox(width: 12),
                    Text('Status privacy'),
                  ],
                ),
              ),
              const PopupMenuItem<String>(
                value: 'status_settings',
                child: Row(
                  children: [
                    Icon(Icons.settings, color: Colors.grey),
                    SizedBox(width: 12),
                    Text('Status settings'),
                  ],
                ),
              ),
              const PopupMenuItem<String>(
                value: 'help',
                child: Row(
                  children: [
                    Icon(Icons.help_outline, color: Colors.grey),
                    SizedBox(width: 12),
                    Text('Help'),
                  ],
                ),
              ),
              const PopupMenuDivider(),
              const PopupMenuItem<String>(
                value: 'settings',
                child: Row(
                  children: [
                    Icon(Icons.settings, color: Colors.grey),
                    SizedBox(width: 12),
                    Text('Settings'),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
      body: const UpdatesScreenBody(),
      floatingActionButton: const AddStatusNoteorAddMedia(),
    );
  }
}
