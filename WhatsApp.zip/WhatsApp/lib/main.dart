import 'package:flutter/material.dart';
import 'package:whatsapp_clone/constants/colors.dart';
import 'package:whatsapp_clone/routes.dart';
import 'package:whatsapp_clone/common/screens/homescreen.dart';
import 'package:whatsapp_clone/screens/chats/chat_screen.dart';
import 'package:whatsapp_clone/screens/contacts/models/contact_manager.dart';

void main() {
  // Initialize contacts when app starts
  ContactManager.initializeContacts();
  runApp(const WhatsAppClone());
}

class WhatsAppClone extends StatelessWidget {
  const WhatsAppClone({super.key});

  
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        appBarTheme: const AppBarTheme(
          color: Colors.white,
          iconTheme: IconThemeData(
            color: Colors.black,
          ),
          titleTextStyle: TextStyle(
            color: Colors.black,
            fontSize: 18.0,
            fontWeight: FontWeight.bold,
          ),
          elevation: 1,
        ),
        bottomNavigationBarTheme: const BottomNavigationBarThemeData(
          backgroundColor: kbackgroundColor,
          enableFeedback: false,
          selectedIconTheme: IconThemeData(
            color: kIconColor,
            shadows: [Shadow(color: kbackgroundColor)]
          ),
          selectedItemColor: kTextColor,
          unselectedIconTheme: IconThemeData(
            color: kIconColor,
          ),
          unselectedItemColor: kTextColor,
          type: BottomNavigationBarType.fixed,
        ),
        colorScheme: ColorScheme.fromSeed(seedColor: kPrimaryColor),
        floatingActionButtonTheme: const FloatingActionButtonThemeData(
          backgroundColor: kPrimaryColor,
        ),
        scaffoldBackgroundColor: kbackgroundColor,
        useMaterial3: true,
      ),
  initialRoute: HomeScreen.routeName,
  onGenerateRoute: (settings) {
    if (settings.name == ChatScreen.routeName) {
      final userId = settings.arguments as String?;
      return MaterialPageRoute(
        builder: (context) => ChatScreen(userId: userId),
      );
    }
    // Handle other routes using the routes map
    final builder = routes[settings.name];
    if (builder != null) {
      return MaterialPageRoute(
        builder: (context) => builder(context),
      );
    }
    return null;
  },
  home: const HomeScreen(),
    );
  }
}
