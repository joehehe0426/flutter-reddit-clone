import 'package:flutter/material.dart';
import 'package:whatsapp_clone/screens/settings/settings_screen.dart';


AppBar customAppBar(String title) {
  return AppBar(
    automaticallyImplyLeading: false,
    title: Text(
      title,
      style: const TextStyle(
        fontSize: 20.0,
      ),
    ),
    actions: [
      IconButton(
        onPressed: () {}, 
        icon: const Icon(Icons.camera_alt_outlined),
      ),
      IconButton(
        onPressed: () {}, 
        icon: const Icon(Icons.search_outlined),
      ),
      PopupMenuButton<String>(
        icon: const Icon(Icons.more_vert),
        onSelected: (value) {
          // Handle menu item selection
          switch (value) {
            case 'settings':
              // Navigate to settings
              break;
            case 'help':
              // Show help
              break;
            case 'about':
              // Show about
              break;
          }
        },
        itemBuilder: (BuildContext context) => <PopupMenuEntry<String>>[
          const PopupMenuItem<String>(
            value: 'settings',
            child: Row(
              children: [
                Icon(Icons.settings, color: Colors.grey),
                SizedBox(width: 12),
                Text('Settings'),
              ],
            ),
          ),
          const PopupMenuItem<String>(
            value: 'help',
            child: Row(
              children: [
                Icon(Icons.help_outline, color: Colors.grey),
                SizedBox(width: 12),
                Text('Help'),
              ],
            ),
          ),
          const PopupMenuItem<String>(
            value: 'about',
            child: Row(
              children: [
                Icon(Icons.info_outline, color: Colors.grey),
                SizedBox(width: 12),
                Text('About'),
              ],
            ),
          ),
        ],
      ),
    ],
  );
}
