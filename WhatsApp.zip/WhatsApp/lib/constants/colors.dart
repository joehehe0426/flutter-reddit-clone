import 'package:flutter/material.dart';


// WhatsApp-like color palette
const kPrimaryColor = Color(0xFF25D366); // Lighter WhatsApp green
const kbackgroundColor = Color(0xFFFFFFFF); // Main page background: white
const kTextColor = Color(0xFF111B21); // Main text: dark
const kTextDarkColor = Color(0xFF667781); // Subdued text
const kIconColor = Color(0xFF54656F); // Icon color
const kAppBarColor = Color(0xFF075E54); // AppBar: WhatsApp green
const kmessageBubbleColor = Color(0xFFFFFFFF); // Received message: white
const ksenderMessageBubbleColor = Color(0xFFE7FFDB); // Sent message: light green
const kBlueTickColor = Color(0xFF34B7F1); // Blue tick
const kGreyTickColor = Color(0xFFBFC9CE); // Grey tick
const kTabColor = Color(0xFF25D366); // Tab indicator: WhatsApp accent green
const ksearchBarColor = Color(0xFFF0F0F0); // Search bar: light grey
const kDividerColor = Color(0xFFE9EDEF); // Divider: very light grey
const kchatBarMessage = Color(0xFFF7F7F8); // Chat input bar: very light grey
const kmobileChatBoxColor = Color(0xFFF7F7F8); // Mobile chat box: very light grey