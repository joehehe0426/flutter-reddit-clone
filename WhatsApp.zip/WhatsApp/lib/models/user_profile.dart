import 'dart:io';
import 'package:flutter/material.dart';

class UserProfile {
  static String? _profileImagePath;
  static String _username = 'Joe';
  static String _bio = 'With great power comes great responsibility.';

  static String get profileImagePath => _profileImagePath ?? 'assets/img/default.png';
  static String get username => _username;
  static String get bio => _bio;

  static void updateProfilePicture(String? imagePath) {
    _profileImagePath = imagePath;
  }

  static void updateUsername(String username) {
    _username = username;
  }

  static void updateBio(String bio) {
    _bio = bio;
  }

  static Widget getProfileImage({double? radius, double? size}) {
    if (_profileImagePath != null && _profileImagePath!.startsWith('/')) {
      // File path from image picker
      return CircleAvatar(
        radius: radius,
        backgroundImage: FileImage(File(_profileImagePath!)),
      );
    } else {
      // Asset path
      return CircleAvatar(
        radius: radius,
        backgroundImage: AssetImage(_profileImagePath ?? 'assets/img/default.png'),
      );
    }
  }
}
