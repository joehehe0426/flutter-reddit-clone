class User {
  final String username;
  final String profilePicture;
  final String id;

  User({
    required this.username,
    required this.profilePicture,
    required this.id,
  });

  factory User.fromMap(Map<String, dynamic> map) {
    return User(
      username: map['username'] ?? '',
      profilePicture: map['profilePicture'] ?? '',
      id: map['id'] ?? '',
    );
  }
}

final List<User> users = [
  // HK demo conversation entry (groups and threads)
  User(
    id: "hk_demo",
    username: "家庭群組",
    profilePicture: "assets/img/dps/1.jpg",
  ),
  User(
    id: "hk_group_friends",
    username: "老友群",
    profilePicture: "assets/img/dps/2.jpg",
  ),
  User(
    id: "hk_group_girls",
    username: "女生群",
    profilePicture: "assets/img/girls_talk.png",
  ),
  User(
    id: "hk_akiang_ahui",
    username: "阿強",
    profilePicture: "assets/img/dps/4.jpg",
  ),
  User(
    id: "hk_mama_mrs_chan",
    username: "Auntie Apple",
    profilePicture: "assets/img/dps/5.jpg",
  ),
  
  // Family Members (7 people - exact match with chat history)
  User(
    id: "hk_family_grandpa",
    username: "爺爺",
    profilePicture: "assets/img/dps/6.jpg",
  ),
  User(
    id: "hk_family_grandma",
    username: "奶奶",
    profilePicture: "assets/img/dps/7.jpg",
  ),
  User(
    id: "hk_family_dad",
    username: "爸爸",
    profilePicture: "assets/img/dps/8.jpg",
  ),
  User(
    id: "hk_family_mom",
    username: "媽媽",
    profilePicture: "assets/img/dps/9.jpg",
  ),
  User(
    id: "hk_family_brother",
    username: "阿哥",
    profilePicture: "assets/img/dps/10.jpeg",
  ),
  User(
    id: "hk_family_sister",
    username: "阿妹",
    profilePicture: "assets/img/dps/11.jpeg",
  ),
  User(
    id: "hk_family_cousin",
    username: "表妹",
    profilePicture: "assets/img/dps/12.jpeg",
  ),
  
  // Friends & Other Characters (8 people - exact match with chat history)
  User(
    id: "hk_friend_akiang",
    username: "阿強",
    profilePicture: "assets/img/dps/13.jpg",
  ),
  User(
    id: "hk_friend_ahui",
    username: "阿輝",
    profilePicture: "assets/img/dps/14.jpg",
  ),
  User(
    id: "hk_friend_alin",
    username: "阿琳",
    profilePicture: "assets/img/dps/15.jpg",
  ),
  User(
    id: "hk_friend_senior_brother",
    username: "師兄",
    profilePicture: "assets/img/dps/16.jpg",
  ),
  User(
    id: "hk_friend_ating",
    username: "阿婷",
    profilePicture: "assets/img/dps/17.jpg",
  ),
  User(
    id: "hk_neighbor_mrs_chan",
    username: "鄰居陳太",
    profilePicture: "assets/img/dps/18.jpg",
  ),
  User(
    id: "hk_friend_secretary",
    username: "書記",
    profilePicture: "assets/img/dps/19.jpg",
  ),
  User(
    id: "hk_cafe_uncle",
    username: "Uncle Ben",
    profilePicture: "assets/img/dps/20.jpg",
  ),

  // Additional girls for girls group
  User(
    id: "hk_girl_mei",
    username: "阿美",
    profilePicture: "assets/img/dps/1.jpg",
  ),
  User(
    id: "hk_girl_fung",
    username: "阿芳",
    profilePicture: "assets/img/dps/2.jpg",
  ),
  User(
    id: "hk_girl_yuen",
    username: "阿圓",
    profilePicture: "assets/img/dps/3.jpg",
  ),
  User(
    id: "hk_girl_choi",
    username: "阿彩",
    profilePicture: "assets/img/dps/4.jpg",
  ),
  User(
    id: "hk_girl_jenny",
    username: "Jenny",
    profilePicture: "assets/img/dps/21.jpg",
  ),
  User(
    id: "hk_girl_virg",
    username: "Virg",
    profilePicture: "assets/img/dps/20.jpg",
  ),
  User(
    id: "pin_biz_sarah_vine",
    username: "Sarah（Vine & Co.）",
    profilePicture: "assets/img/Sarah.png",
  ),
];
