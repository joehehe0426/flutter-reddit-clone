import 'package:whatsapp_clone/models/users.dart';
import 'package:whatsapp_clone/models/hk_mock_history.dart' as hk;
class ChatMessage {
  final String message;
  final String timeStamp;
  final bool isSender;
  final String date;
  final bool isReceived;
  final bool isRead;
  final String? senderName;
  // Optional attachments
  final String? imageAsset; // e.g., assets/img/Ponti.png
  final String? fileAsset;  // e.g., assets/pdf/xxx.pdf

  ChatMessage({
    required this.message,
    required this.timeStamp,
    required this.isSender,
    required this.date,
    this.isReceived = false,
    this.isRead = false,
    this.senderName,
    this.imageAsset,
    this.fileAsset,
  });

  // Convert map to ChatMessage object
  factory ChatMessage.fromMap(Map<String, dynamic> map) {
    return ChatMessage(
      message: map['message'] ?? '',
      timeStamp: map['timeStamp'] ?? '',
      isSender: map['isSender'] ?? false,
      date: map['date'] ?? '',
      isReceived: map['isReceived'] ?? false,
      isRead: map['isRead'] ?? false,
      senderName: map['senderName'],
      imageAsset: map['imageAsset'],
      fileAsset: map['fileAsset'],
    );
  }
}


// Unique chat histories for each user (keyed by user id)
final Map<String, List<ChatMessage>> userChatHistories = {
  // HK demo mapped into existing model
  'hk_demo': [
    ...hk.hkChatHistory
        .where((m) => m.recipient == '家庭群組')
        .take(20)
        .expand((m) {
          final List<ChatMessage> out = [
            ChatMessage(
              message: m.message,
              timeStamp: m.timestamp,
              isSender: false,
              date: m.date,
              isReceived: true,
              isRead: true,
              senderName: m.sender,
            ),
          ];
          if (m.id == '7-28-2' && m.sender == '阿妹') {
            out.add(ChatMessage(
              message: '',
              timeStamp: m.timestamp,
              isSender: false,
              date: m.date,
              isReceived: true,
              isRead: true,
              senderName: m.sender,
              imageAsset: 'assets/img/attachment/Attachment1.png',
            ));
          }
          if (m.id == '7-28-3' && m.sender == '爸爸') {
            out.add(ChatMessage(
              message: '',
              timeStamp: m.timestamp,
              isSender: false,
              date: m.date,
              isReceived: true,
              isRead: true,
              senderName: m.sender,
              imageAsset: 'assets/img/attachment/Attachment2.png',
            ));
            out.add(ChatMessage(
              message: '下，咁都要150蚊呀',
              timeStamp: '09:21',
              isSender: true,
              date: m.date,
            ));
          }
          return out;
        })
        .toList(),
  ],
  'hk_group_friends': [
    ...hk.hkChatHistory
        .where((m) => m.recipient == '老友群')
        .take(20)
        .map((m) => ChatMessage(
              message: m.message,
              timeStamp: m.timestamp,
              isSender: false,
              date: m.date,
              isReceived: true,
              isRead: true,
              senderName: m.sender,
            )),
  ],
  'hk_group_girls': [
    ...hk.mergedHkChatHistory
        .where((m) => m.recipient == '女生群')
        .expand((m) {
          final List<ChatMessage> out = [
            ChatMessage(
              message: m.message,
              timeStamp: m.timestamp,
              isSender: false,
              date: m.date,
              isReceived: true,
              isRead: true,
              senderName: m.sender,
            ),
          ];
          final text = m.message;
          String? img;
          if (m.sender == '阿婷' && (text.contains('相機') || text.contains('影'))) {
            img = 'assets/img/dps/15.jpg';
          } else if (m.sender == '阿琳' && (text.contains('相') || text.contains('影'))) {
            img = 'assets/img/dps/3.jpg';
          } else if (m.sender == '阿妹' && (text.contains('草莓') || text.contains('買'))) {
            img = 'assets/img/dps/1.jpg';
          }
          if (img != null) {
            out.add(ChatMessage(
              message: '',
              timeStamp: m.timestamp,
              isSender: false,
              date: m.date,
              isReceived: true,
              isRead: true,
              senderName: m.sender,
              imageAsset: img,
            ));
          }
          return out;
        })
        .toList(),
  ],
  'hk_akiang_ahui': [
    ...hk.hkChatHistory
        .where((m) => !m.isGroupChat && ((m.sender == '阿強' && m.recipient == '阿輝') || (m.sender == '阿輝' && m.recipient == '阿強')))
        .take(20)
        .map((m) => ChatMessage(
              message: m.message,
              timeStamp: m.timestamp,
              isSender: m.sender == '我',
              date: m.date,
              isReceived: true,
              isRead: true,
            )),
  ],
  'hk_mama_mrs_chan': [
    ...hk.hkChatHistory
        .where((m) => !m.isGroupChat && ((m.sender == '媽媽' && m.recipient == '鄰居陳太') || (m.sender == '鄰居陳太' && m.recipient == '媽媽')))
        .take(20)
        .map((m) => ChatMessage(
              message: m.message,
              timeStamp: m.timestamp,
              isSender: false,
              date: m.date,
              isReceived: true,
              isRead: true,
            )),
  ],
  'pin_biz_sarah_vine': [
    ChatMessage(
      message: 'Sarah 下午好！我是Grace，來自WineCellarHK, 上週香港酒展跟你聊過「低干预釀造」酒款，還記得嗎？😉 最近到了2021年布根地夜丘黑皮諾 (全港僅240瓶），很適合你們 7 月中更換的秋季杯賣清單，先發酒標和報價單給你參考',
      timeStamp: '15:12',
      isSender: true,
      date: '2025-06-28',
    ),
    // Attachments sent with the intro message
    ChatMessage(
      message: '酒標（Ponti.png）',
      timeStamp: '15:12',
      isSender: true,
      date: '2025-06-28',
      imageAsset: 'assets/img/Ponti.png',
    ),
    ChatMessage(
      message: '報價單（PDF）',
      timeStamp: '15:12',
      isSender: true,
      date: '2025-06-28',
      fileAsset: 'assets/pdf/WINE-QT-20240628-001.pdf',
    ),
    ChatMessage(
      message: '哦！當然記得～你們的低干预酒款很符合我們客人的偏好！這款黑皮諾的產地和口感描述很吸引，麻煩先送 1 瓶樣酒試飲，下週五團隊試菜時測配餐效果～\n樣酒送後門酒庫就行，聯絡人王師傅，到之前可以先給他打個電話。',
      timeStamp: '15:25',
      isSender: false,
      date: '2025-06-28',
      senderName: 'Sarah（Vine & Co.）',
    ),
    ChatMessage(
      message: '收到！樣酒明天（6 月 29 日）下午 4 點送過去，到前 10 分鐘聯絡王師傅～如果試飲通過，你們確認訂貨後，我會發正式訂單（PO）給你簽回，憑簽回 PO 安排送貨。',
      timeStamp: '15:30',
      isSender: true,
      date: '2025-06-28',
    ),
    ChatMessage(
      message: 'Hi Grace！上週試的黑皮諾團隊全票通過，客人試飲反饋也很好～確定訂 24 瓶，麻煩出 PO 給我，我簽回後發你。\n送貨時間下週一（7 月 15 日）上午 10 點，還是後門酒庫找王師傅，送貨時記得帶商業發票，我們需要留存報銷。',
      timeStamp: '11:08',
      isSender: false,
      date: '2025-07-10',
      senderName: 'Sarah（Vine & Co.）',
    ),
    ChatMessage(
      message: '太好了！PO 我馬上做，10 分鐘內發你 WhatsApp，你簽回後請傳回 PDF 版～另外跟你確認：你們是月結客戶，這筆訂單會算在 7 月賬單裡，8 月 5 日前轉賬至我們公司賬戶就行。\n送貨當天我會讓物流帶上送貨單，王師傅簽收後我們會掃描傳你一份，作為收貨憑證。',
      timeStamp: '11:15',
      isSender: true,
      date: '2025-07-10',
    ),
    ChatMessage(
      message: '好，PO 收到後我半小時內簽回～月結方式沒問題，8 月 5 日前一定轉賬。',
      timeStamp: '11:20',
      isSender: false,
      date: '2025-07-10',
      senderName: 'Sarah（Vine & Co.）',
    ),
    ChatMessage(
      message: 'Hi Sarah, 7月訂的24瓶黑皮諾只剩 3 瓶，要不要補貨？另外新到 2020 年納帕谷赤霞珠（報價 HKD 520 / 瓶，10 瓶以上 9 折），配你們新上的烤和牛肋排超搭，樣酒下週三（8 月 7 日）送過去？\n補貨的話，這批黑皮諾還是 HKD 646 / 瓶，一起出 PO 更方便，下週三送貨時一併結算。',
      timeStamp: '16:40',
      isSender: true,
      date: '2025-08-05',
    ),
    ChatMessage(
      message: '黑皮諾先補 8 瓶（總計 HKD 5168），赤霞珠試樣後再定～樣酒下週三下午 3 點送，PO 我明天（8 月 6 日）讓助理出給你。',
      timeStamp: '16:50',
      isSender: false,
      date: '2025-08-05',
      senderName: 'Sarah（Vine & Co.）',
    ),
    ChatMessage(
      message: 'Hi Grace，赤霞珠試飲通過，訂 15 瓶（9 折後單價 HKD 468，總計 HKD 7020），另外黑皮諾 9 月補貨 10 瓶（HKD 6460），麻煩一起出 9 月的 PO，註明「分兩批送：赤霞珠 9 月 1 日送，黑皮諾 9 月 16 日送」。\n7 月的賬單我們昨天（8 月 27 日）已經轉賬了，轉賬憑證發你，請查收～',
      timeStamp: '10:22',
      isSender: false,
      date: '2025-08-28',
      senderName: 'Sarah（Vine & Co.）',
    ),
    ChatMessage(
      message: '收到轉賬憑證！後續會核對到賬情況～9 月的 PO 我今天下午出，註明分兩批送貨，你簽回後我安排物流～赤霞珠送貨時一樣帶商業發票和送貨單，王師傅簽收後傳你憑證。',
      timeStamp: '10:30',
      isSender: true,
      date: '2025-08-28',
    ),
  ],
};

// User model to match your user list

// Generate user messages with proper typing
List<Map<String, dynamic>> generateUserMessages(List<User> users) {
  return users.map((user) {
    final userMsgs = userChatHistories[user.id] ?? [];
    final lastMsg = userMsgs.isNotEmpty ? userMsgs.last : null;
    return {
      "username": user.username,
      "profilePicture": user.profilePicture,
      "message": lastMsg?.message ?? "",
      "timeStamp": lastMsg?.timeStamp ?? "",
      "messageTick": lastMsg ?? ChatMessage(
        message: "", 
        timeStamp: "", 
        isSender: false, 
        date: ""
      ),
    };
  }).toList();
}
