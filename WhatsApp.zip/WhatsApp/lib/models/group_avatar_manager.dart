import 'package:shared_preferences/shared_preferences.dart';
import 'dart:developer' as developer;

class GroupAvatarManager {
  static const String _prefsKeyPrefix = 'group_avatar_';

  static Future<void> saveGroupAvatar(String groupId, String imagePath) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final key = '$_prefsKeyPrefix$groupId';
      await prefs.setString(key, imagePath);

      // Verify it was saved
      final saved = prefs.getString(key);
      developer.log('GroupAvatarManager: Saved avatar for $groupId: $saved');
    } catch (e) {
      developer.log('GroupAvatarManager: Error saving avatar: $e');
    }
  }

  static Future<String?> getGroupAvatar(String groupId) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final key = '$_prefsKeyPrefix$groupId';
      final avatarPath = prefs.getString(key);

      developer.log('GroupAvatarManager: Loaded avatar for $groupId: $avatarPath');
      return avatarPath;
    } catch (e) {
      developer.log('GroupAvatarManager: Error loading avatar: $e');
      return null;
    }
  }

  static Future<void> removeGroupAvatar(String groupId) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final key = '$_prefsKeyPrefix$groupId';
      await prefs.remove(key);
      developer.log('GroupAvatarManager: Removed avatar for $groupId');
    } catch (e) {
      developer.log('GroupAvatarManager: Error removing avatar: $e');
    }
  }

  static Future<void> clearAllAvatars() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final keys = prefs.getKeys().where((key) => key.startsWith(_prefsKeyPrefix)).toList();
      for (final key in keys) {
        await prefs.remove(key);
      }
      developer.log('GroupAvatarManager: Cleared all avatars');
    } catch (e) {
      developer.log('GroupAvatarManager: Error clearing avatars: $e');
    }
  }
}
