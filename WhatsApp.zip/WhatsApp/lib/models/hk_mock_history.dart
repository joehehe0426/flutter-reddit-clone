// Removed unused intl import

class HkChatMessage {
  final String id;
  final String sender;
  final String recipient;
  final String message;
  final String timestamp;
  final String date;
  final bool isGroupChat;
  final List<String>? groupMembers;

  HkChatMessage({
    required this.id,
    required this.sender,
    required this.recipient,
    required this.message,
    required this.timestamp,
    required this.date,
    this.isGroupChat = false,
    this.groupMembers,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'sender': sender,
      'recipient': recipient,
      'message': message,
      'timestamp': timestamp,
      'date': date,
      'isGroupChat': isGroupChat,
      'groupMembers': groupMembers,
    };
  }
}

// 15 Characters (Family + Friends)
const List<String> characters = [
  // Family
  "爺爺", "奶奶", "爸爸", "媽媽", "阿哥", "阿妹", "表妹",
  // Friends
  "阿強", "阿琳", "師兄", "阿婷", "鄰居陳太", "阿輝", "書記", "茶餐廳阿叔"
];

// Chat History: July 28 - August 28, 2025
List<HkChatMessage> hkChatHistory = [
  // ==================== July 28 (Monday) ====================
  // Family Group
  HkChatMessage(
    id: "7-28-1",
    sender: "奶奶",
    recipient: "家庭群組",
    message: "今日熱到溶啊！阿妹，放學千祈唔好去遊水，聽日有雷暴警告～",
    timestamp: "09:05",
    date: "2025-07-28",
    isGroupChat: true,
    groupMembers: characters.sublist(0, 7),
  ),
  HkChatMessage(
    id: "7-28-2",
    sender: "阿妹",
    recipient: "家庭群組",
    message: "知道啦！但同阿婷約咗去商場吹冷氣，買新筆袋～",
    timestamp: "09:10",
    date: "2025-07-28",
    isGroupChat: true,
    groupMembers: characters.sublist(0, 7),
  ),
  HkChatMessage(
    id: "7-28-3",
    sender: "爸爸",
    recipient: "家庭群組",
    message: "早晨！MTR東鐵線又遲到，今日要搭的士返工，蝕咗\$150😫",
    timestamp: "09:20",
    date: "2025-07-28",
    isGroupChat: true,
    groupMembers: characters.sublist(0, 7),
  ),
  HkChatMessage(
    id: "7-28-4",
    sender: "媽媽",
    recipient: "家庭群組",
    message: "市場今日有新鮮荔枝，\$10一磅！我買咗3斤，今晚凍鎮食～",
    timestamp: "09:30",
    date: "2025-07-28",
    isGroupChat: true,
    groupMembers: characters.sublist(0, 7),
  ),
  HkChatMessage(
    id: "7-28-5",
    sender: "爺爺",
    recipient: "家庭群組",
    message: "我今日約咗李伯去海灘釣魚，夠晒清涼～",
    timestamp: "09:40",
    date: "2025-07-28",
    isGroupChat: true,
    groupMembers: characters.sublist(0, 7),
  ),

  // 阿強 & 阿輝 (Private)
  HkChatMessage(
    id: "7-28-6",
    sender: "阿強",
    recipient: "阿輝",
    message: "喂！聽日放工去唔去旺角睇戲？新出嘅警匪片好似幾好睇",
    timestamp: "12:15",
    date: "2025-07-28",
  ),
  HkChatMessage(
    id: "7-28-7",
    sender: "阿輝",
    recipient: "阿強",
    message: "得！但我要先去銅鑼灣交健身課程表，不如7點在戲院門口見？",
    timestamp: "12:20",
    date: "2025-07-28",
  ),

  // 媽媽 & 鄰居陳太 (Private)
  HkChatMessage(
    id: "7-28-8",
    sender: "媽媽",
    recipient: "鄰居陳太",
    message: "阿陳，你個孫嘅暑假作業做完未？阿妹話好多數學題唔識做",
    timestamp: "15:30",
    date: "2025-07-28",
  ),
  HkChatMessage(
    id: "7-28-9",
    sender: "鄰居陳太",
    recipient: "媽媽",
    message: "未啊！佢成日玩手機～ 不如聽日下午叫佢哋一齊嚟我屋企做？我幫佢哋補習",
    timestamp: "15:35",
    date: "2025-07-28",
  ),

  // Friends Group (阿琳, 書記, 阿婷)
  HkChatMessage(
    id: "7-28-10",
    sender: "阿琳",
    recipient: "女生群",
    message: "周末去長洲玩？聽說新開咗間芒果糯米糍好正！",
    timestamp: "16:40",
    date: "2025-07-28",
    isGroupChat: true,
    groupMembers: ["阿琳", "書記", "阿婷"],
  ),
  HkChatMessage(
    id: "7-28-11",
    sender: "書記",
    recipient: "女生群",
    message: "我得！但要早啲返，周日圖書館有讀書會～",
    timestamp: "16:45",
    date: "2025-07-28",
    isGroupChat: true,
    groupMembers: ["阿琳", "書記", "阿婷"],
  ),
  // ... (15+ messages total for July 28)
  // Midday and evening additions (家庭群組)
  HkChatMessage(
    id: "7-28-12",
    sender: "阿哥",
    recipient: "家庭群組",
    message: "媽，晏晝記得幫我攞衫，唔該晒！",
    timestamp: "12:35",
    date: "2025-07-28",
    isGroupChat: true,
    groupMembers: characters.sublist(0, 7),
  ),
  HkChatMessage(
    id: "7-28-13",
    sender: "奶奶",
    recipient: "家庭群組",
    message: "出面好熱呀，記得飲多啲水～",
    timestamp: "13:10",
    date: "2025-07-28",
    isGroupChat: true,
    groupMembers: characters.sublist(0, 7),
  ),
  HkChatMessage(
    id: "7-28-14",
    sender: "爸爸",
    recipient: "家庭群組",
    message: "收咗工，搭緊車返屋企。今晚有冇咩想食？",
    timestamp: "18:20",
    date: "2025-07-28",
    isGroupChat: true,
    groupMembers: characters.sublist(0, 7),
  ),
  HkChatMessage(
    id: "7-28-15",
    sender: "阿妹",
    recipient: "家庭群組",
    message: "今晚食乜餸呀？我想食番茄炒蛋～",
    timestamp: "18:25",
    date: "2025-07-28",
    isGroupChat: true,
    groupMembers: characters.sublist(0, 7),
  ),


  // ==================== August 5 (Tuesday) ====================
  // Family Group
  HkChatMessage(
    id: "8-5-1",
    sender: "阿哥",
    recipient: "家庭群組",
    message: "我暑假工個老闆話俾我加人工！由\$60/hr升到\$70，厲害嗎？😎",
    timestamp: "08:10",
    date: "2025-08-05",
    isGroupChat: true,
    groupMembers: characters.sublist(0, 7),
  ),
  HkChatMessage(
    id: "8-5-2",
    sender: "媽媽",
    recipient: "家庭群組",
    message: "犀利！不如請大家食麥當勞？阿妹話想食新出嘅芒果批～",
    timestamp: "08:15",
    date: "2025-08-05",
    isGroupChat: true,
    groupMembers: characters.sublist(0, 7),
  ),
  HkChatMessage(
    id: "8-5-3",
    sender: "爺爺",
    recipient: "家庭群組",
    message: "麥當勞唔健康！不如我請去茶餐廳食西多士，阿叔個新出嘅花生醬味好正",
    timestamp: "08:20",
    date: "2025-08-05",
    isGroupChat: true,
    groupMembers: characters.sublist(0, 7),
  ),

  // 茶餐廳阿叔 & 爺爺 (Private)
  HkChatMessage(
    id: "8-5-4",
    sender: "茶餐廳阿叔",
    recipient: "爺爺",
    message: "阿伯！聽日早啲嚟，我留咗新鮮出炉嘅老婆餅俾你，熱辣辣最好食～",
    timestamp: "09:30",
    date: "2025-08-05",
  ),
  HkChatMessage(
    id: "8-5-5",
    sender: "爺爺",
    recipient: "茶餐廳阿叔",
    message: "多謝阿叔！我9點到，同張伯一齊嚟，佢話要試你個沙嗲牛肉公仔麵",
    timestamp: "09:35",
    date: "2025-08-05",
  ),

  // 阿妹 & 阿婷 (Private)
  HkChatMessage(
    id: "8-5-6",
    sender: "阿妹",
    recipient: "阿婷",
    message: "開學要換新校服啦，你媽媽陪你去買未？我媽話周六去旺角那間「學生天地」",
    timestamp: "14:20",
    date: "2025-08-05",
  ),
  HkChatMessage(
    id: "8-5-7",
    sender: "阿婷",
    recipient: "阿妹",
    message: "未啊！不如一齊去？聽說買兩套有8折，仲送校鞋～",
    timestamp: "14:25",
    date: "2025-08-05",
  ),
  // ... (15+ messages total for August 5)
  // Midday and evening additions (家庭群組)
  HkChatMessage(
    id: "8-5-12",
    sender: "媽媽",
    recipient: "家庭群組",
    message: "早晨呀～ 今日記得帶遮，可能有驟雨",
    timestamp: "07:55",
    date: "2025-08-05",
    isGroupChat: true,
    groupMembers: characters.sublist(0, 7),
  ),
  HkChatMessage(
    id: "8-5-13",
    sender: "阿哥",
    recipient: "家庭群組",
    message: "媽，晏晝記得幫我攞衫，唔該～",
    timestamp: "12:25",
    date: "2025-08-05",
    isGroupChat: true,
    groupMembers: characters.sublist(0, 7),
  ),
  HkChatMessage(
    id: "8-5-14",
    sender: "爸爸",
    recipient: "家庭群組",
    message: "收咗工，搭緊車返屋企，約6點半到～",
    timestamp: "18:05",
    date: "2025-08-05",
    isGroupChat: true,
    groupMembers: characters.sublist(0, 7),
  ),


  // ==================== August 15 (Friday) ====================
  // Typhoon Signal 3 Day
  HkChatMessage(
    id: "8-15-1",
    sender: "爸爸",
    recipient: "家庭群組",
    message: "天文台掛3號波啦！公司話可以早啲放工，我4點左右返嚟～",
    timestamp: "10:00",
    date: "2025-08-15",
    isGroupChat: true,
    groupMembers: characters.sublist(0, 7),
  ),
  HkChatMessage(
    id: "8-15-2",
    sender: "媽媽",
    recipient: "家庭群組",
    message: "我剛剛去街市搶咗兩包米同幾罐午餐肉，怕陣間落大雨出唔到門～",
    timestamp: "10:10",
    date: "2025-08-15",
    isGroupChat: true,
    groupMembers: characters.sublist(0, 7),
  ),
  HkChatMessage(
    id: "8-15-3",
    sender: "阿妹",
    recipient: "家庭群組",
    message: "學校話今日下晝唔使返學！我可以同阿婷打機啦～",
    timestamp: "10:15",
    date: "2025-08-15",
    isGroupChat: true,
    groupMembers: characters.sublist(0, 7),
  ),

  // 師兄 & 阿強 (Private)
  HkChatMessage(
    id: "8-15-4",
    sender: "師兄",
    recipient: "阿強",
    message: "今日行山計劃取消啦！山徑太濕滑，聽日再算～",
    timestamp: "11:30",
    date: "2025-08-15",
  ),
  HkChatMessage(
    id: "8-15-5",
    sender: "阿強",
    recipient: "師兄",
    message: "好彩你話！我剛剛準備出門，見到外面風好大，衫都吹到飛～",
    timestamp: "11:35",
    date: "2025-08-15",
  ),
  // ... (15+ messages total for August 15)
  // Midday and evening additions (家庭群組)
  HkChatMessage(
    id: "8-15-12",
    sender: "奶奶",
    recipient: "家庭群組",
    message: "早晨呀，記得關好窗，外面風好大～",
    timestamp: "08:05",
    date: "2025-08-15",
    isGroupChat: true,
    groupMembers: characters.sublist(0, 7),
  ),
  HkChatMessage(
    id: "8-15-13",
    sender: "阿妹",
    recipient: "家庭群組",
    message: "出面好熱呀～ 我落街買雪糕！",
    timestamp: "12:40",
    date: "2025-08-15",
    isGroupChat: true,
    groupMembers: characters.sublist(0, 7),
  ),
  HkChatMessage(
    id: "8-15-14",
    sender: "媽媽",
    recipient: "家庭群組",
    message: "今晚食乜餸？有魚有菜～ 早啲返嚟食呀",
    timestamp: "18:10",
    date: "2025-08-15",
    isGroupChat: true,
    groupMembers: characters.sublist(0, 7),
  ),


  // ==================== August 28 (Today) ====================
  // Family Group
  HkChatMessage(
    id: "8-28-1",
    sender: "奶奶",
    recipient: "家庭群組",
    message: "終於涼快少少啦！今日28度，比尋日降咗5度～ 阿妹，開學用品買齊未？",
    timestamp: "06:50",
    date: "2025-08-28",
    isGroupChat: true,
    groupMembers: characters.sublist(0, 7),
  ),
  HkChatMessage(
    id: "8-28-2",
    sender: "阿妹",
    recipient: "家庭群組",
    message: "買齊啦！昨日同阿婷去買咗新筆盒同練習簿，仲有老師要嘅科學实验套裝～",
    timestamp: "07:00",
    date: "2025-08-28",
    isGroupChat: true,
    groupMembers: characters.sublist(0, 7),
  ),
  HkChatMessage(
    id: "8-28-3",
    sender: "爸爸",
    recipient: "家庭群組",
    message: "今日公司有新同事，要早啲返去介紹。媽媽，今晚食咩？我想食你整嘅番茄薯仔湯",
    timestamp: "07:10",
    date: "2025-08-28",
    isGroupChat: true,
    groupMembers: characters.sublist(0, 7),
  ),
  HkChatMessage(
    id: "8-28-4",
    sender: "媽媽",
    recipient: "家庭群組",
    message: "得！市場買咗新鮮番茄，仲有豬骨，煲出來夠濃～ 表妹今晚過來食飯嗎？",
    timestamp: "07:15",
    date: "2025-08-28",
    isGroupChat: true,
    groupMembers: characters.sublist(0, 7),
  ),
  HkChatMessage(
    id: "8-28-5",
    sender: "表妹",
    recipient: "家庭群組",
    message: "來！今晚早收工，約咗同事換班～ 爺爺，上次你話想食嘅杏仁餅，我買咗無糖版～",
    timestamp: "07:20",
    date: "2025-08-28",
    isGroupChat: true,
    groupMembers: characters.sublist(0, 7),
  ),

  // Friends Group (阿琳, 阿強, 阿輝)
  HkChatMessage(
    id: "8-28-6",
    sender: "阿琳",
    recipient: "老友群",
    message: "下周日去西環個新開嘅海邊餐廳？聽說日落好靚，仲有龍蝦意粉～",
    timestamp: "09:30",
    date: "2025-08-28",
    isGroupChat: true,
    groupMembers: ["阿琳", "阿強", "阿輝"],
  ),
  HkChatMessage(
    id: "8-28-7",
    sender: "阿強",
    recipient: "老友群",
    message: "得！但我要帶埋女友，得唔得？佢話想試吓個餐廳嘅招牌蛋糕～",
    timestamp: "09:35",
    date: "2025-08-28",
    isGroupChat: true,
    groupMembers: ["阿琳", "阿強", "阿輝"],
  ),
  HkChatMessage(
    id: "8-28-8",
    sender: "阿輝",
    recipient: "老友群",
    message: "我要5點先收工，不如6點在堅尼地城站見？我知條捷徑去海邊，快10分鐘～",
    timestamp: "09:40",
    date: "2025-08-28",
    isGroupChat: true,
    groupMembers: ["阿琳", "阿強", "阿輝"],
  ),
  // ... (15+ messages total for August 28)
  // Midday and evening additions (家庭群組)
  HkChatMessage(
    id: "8-28-12",
    sender: "爺爺",
    recipient: "家庭群組",
    message: "早晨呀，各位～ 今日氣溫舒服啲",
    timestamp: "07:30",
    date: "2025-08-28",
    isGroupChat: true,
    groupMembers: characters.sublist(0, 7),
  ),
  HkChatMessage(
    id: "8-28-13",
    sender: "阿妹",
    recipient: "家庭群組",
    message: "媽，晏晝幫我攞下制服～ 放學要換",
    timestamp: "12:15",
    date: "2025-08-28",
    isGroupChat: true,
    groupMembers: characters.sublist(0, 7),
  ),
  HkChatMessage(
    id: "8-28-14",
    sender: "爸爸",
    recipient: "家庭群組",
    message: "收咗工，搭緊車返屋企。今晚買多兩個包～",
    timestamp: "18:18",
    date: "2025-08-28",
    isGroupChat: true,
    groupMembers: characters.sublist(0, 7),
  ),

];

// ------ External girls group chat (subset merged) ------
final List<HkChatMessage> girlsGroupAdditions = [
  // 6/28 full subset from provided file (1..40)
  HkChatMessage(id: "gg-6-28-1", sender: "阿婷", recipient: "女生群", message: "終於考完最後一科化學啦！暑假第一日，去海洋公園玩好不好？學生票\$198咋！", timestamp: "09:30", date: "2025-06-28", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-28-2", sender: "阿妹", recipient: "女生群", message: "好啊好啊！想玩新開嘅「鯊魚過山車」～ 不過要早啲去，上次排咗1個鐘！", timestamp: "09:32", date: "2025-06-28", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-28-3", sender: "書記", recipient: "女生群", message: "我唔敢玩過山車... 可以去睇北極企鵝館嗎？聽同事話新到咗3隻BB企鵝～", timestamp: "09:35", date: "2025-06-28", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-28-4", sender: "阿琳", recipient: "女生群", message: "可以分開玩再集合～ 我帶紫菜同朱古力，排隊時可以食", timestamp: "09:38", date: "2025-06-28", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-28-5", sender: "阿婷", recipient: "女生群", message: "我帶新買嘅相機去！企鵝館光線好，影相一定靚～ 聽日幾點集合？", timestamp: "09:40", date: "2025-06-28", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-28-6", sender: "阿琳", recipient: "女生群", message: "9點在金鐘站C出口啦～ 一齊坐城巴629號，直達海洋公園", timestamp: "09:42", date: "2025-06-28", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-28-7", sender: "書記", recipient: "女生群", message: "我帶三明治當午餐啦？公園入面嘅漢堡要\$88，好貴", timestamp: "09:45", date: "2025-06-28", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-28-8", sender: "阿妹", recipient: "女生群", message: "我帶草莓！媽咪琴日買咗好多～ 聽日著白色T恤得唔得？", timestamp: "09:48", date: "2025-06-28", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-28-9", sender: "阿婷", recipient: "女生群", message: "白色好襯陽光！我會著藍色短褲，影相顏色會好靚", timestamp: "09:50", date: "2025-06-28", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-28-10", sender: "阿琳", recipient: "女生群", message: "記得帶防曬！聽日32度，紫外線好強", timestamp: "09:52", date: "2025-06-28", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-28-11", sender: "書記", recipient: "女生群", message: "我有支資生堂防曬，SPF50+，可以分俾大家用", timestamp: "09:55", date: "2025-06-28", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-28-12", sender: "阿妹", recipient: "女生群", message: "多謝書記！我最怕曬黑～ 聽日要帶水嗎？", timestamp: "09:58", date: "2025-06-28", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-28-13", sender: "阿琳", recipient: "女生群", message: "帶支細瓶嘅啦，太大支重～ 公園入面有飲品賣，\$15一支凍茶", timestamp: "10:00", date: "2025-06-28", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-28-14", sender: "阿婷", recipient: "女生群", message: "我買咗新嘅自拍桿，聽日可以影大合照～ 仲有廣角鏡頭！", timestamp: "10:02", date: "2025-06-28", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-28-15", sender: "書記", recipient: "女生群", message: "海洋公園個芒果糯米糍好正，\$28一個，等陣一定要買", timestamp: "10:05", date: "2025-06-28", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-28-16", sender: "阿妹", recipient: "女生群", message: "我要食兩個！考完試要好好獎勵自己～", timestamp: "10:08", date: "2025-06-28", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-28-17", sender: "阿琳", recipient: "女生群", message: "我琴日睇天氣報，聽日下晝3點有陣雨，記得帶遮", timestamp: "10:10", date: "2025-06-28", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-28-18", sender: "阿婷", recipient: "女生群", message: "我冇遮... 阿琳可以借我嗎？", timestamp: "10:12", date: "2025-06-28", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-28-19", sender: "阿琳", recipient: "女生群", message: "得！我帶兩把，一把黑色一把粉紅色，你揀啦", timestamp: "10:15", date: "2025-06-28", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-28-20", sender: "書記", recipient: "女生群", message: "我媽咪話聽日港鐵荃灣線維修，可能要早啲出門", timestamp: "10:18", date: "2025-06-28", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-28-21", sender: "阿妹", recipient: "女生群", message: "咁我7點半起身啦，平時都係8點先起", timestamp: "10:20", date: "2025-06-28", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-28-22", sender: "阿婷", recipient: "女生群", message: "我住得近，8點起身都得～ 到時見唔到大家就喺門口個鐘樓等", timestamp: "10:22", date: "2025-06-28", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-28-23", sender: "阿琳", recipient: "女生群", message: "好主意！鐘樓容易認～ 我會穿件黃色T恤，醒目啲", timestamp: "10:25", date: "2025-06-28", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-28-24", sender: "書記", recipient: "女生群", message: "我著條紅色裙，都好易認～ 三明治要唔要加蛋？", timestamp: "10:28", date: "2025-06-28", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-28-25", sender: "阿妹", recipient: "女生群", message: "要要要！我最鍾意加蛋嘅三明治～ 最好係流心蛋！", timestamp: "10:30", date: "2025-06-28", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-28-26", sender: "阿婷", recipient: "女生群", message: "我唔要蛋，多謝～ 考完試覺得好攰，聽日要精神啲", timestamp: "10:32", date: "2025-06-28", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-28-27", sender: "阿琳", recipient: "女生群", message: "我都要加蛋～ 聽日玩完去食魚蛋好不好？銅鑼灣有間「旺角魚蛋王」好正", timestamp: "10:35", date: "2025-06-28", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-28-28", sender: "書記", recipient: "女生群", message: "好啊！再加杯凍檸茶～ 完美搭配", timestamp: "10:38", date: "2025-06-28", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-28-29", sender: "阿妹", recipient: "女生群", message: "我要加辣！魚蛋冇辣唔好食～ 要加埋芥辣", timestamp: "10:40", date: "2025-06-28", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-28-30", sender: "阿婷", recipient: "女生群", message: "我唔食辣... 到時叫老闆分開整", timestamp: "10:42", date: "2025-06-28", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-28-31", sender: "阿琳", recipient: "女生群", message: "得～ 記得帶學生證，買飛要用到，優惠票要核實身份", timestamp: "10:45", date: "2025-06-28", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-28-32", sender: "書記", recipient: "女生群", message: "收到！我放咗係銀包入面～ 仲有八達通都要帶齊", timestamp: "10:48", date: "2025-06-28", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-28-33", sender: "阿妹", recipient: "女生群", message: "我都放咗係書包度～ 聽日見！我去收拾書包先", timestamp: "10:50", date: "2025-06-28", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-28-34", sender: "阿婷", recipient: "女生群", message: "聽日見～ 我去充電話電池同相機電池先", timestamp: "10:52", date: "2025-06-28", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-28-35", sender: "阿琳", recipient: "女生群", message: "我去準備行李，聽日見～ 記得早啲瞓", timestamp: "10:55", date: "2025-06-28", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-28-36", sender: "書記", recipient: "女生群", message: "我去買麵包整三明治～ 聽日見！", timestamp: "10:58", date: "2025-06-28", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-28-37", sender: "阿妹", recipient: "女生群", message: "剛剛媽咪話聽日可以送我去金鐘，唔使搭港鐵啦～ 開心！", timestamp: "15:30", date: "2025-06-28", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-28-38", sender: "阿婷", recipient: "女生群", message: "好幸福啊～ 我要轉兩次車先到，由觀塘到金鐘", timestamp: "15:35", date: "2025-06-28", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-28-39", sender: "阿琳", recipient: "女生群", message: "我都要轉線～ 不過聽日放假，應該冇咁多人擠", timestamp: "15:40", date: "2025-06-28", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-28-40", sender: "書記", recipient: "女生群", message: "我買咗芝士麵包，整三明治一定好食～ 大家早啲瞓呀，聽日要玩夠本", timestamp: "22:00", date: "2025-06-28", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),

  // 6/29 full subset from provided file (1..40)
  HkChatMessage(id: "gg-6-29-1", sender: "阿琳", recipient: "女生群", message: "早晨！我到金鐘站喇，在鐘樓下面等你地～ 今日天氣好靚！", timestamp: "08:50", date: "2025-06-29", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-29-2", sender: "阿妹", recipient: "女生群", message: "我係車上喇！媽咪開緊車，大概9點05分到～ 草莓已經裝好在保鮮盒", timestamp: "08:55", date: "2025-06-29", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-29-3", sender: "阿婷", recipient: "女生群", message: "我到咗！見到阿琳喇～ 相機已經準備好，電滿哂", timestamp: "09:00", date: "2025-06-29", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-29-4", sender: "書記", recipient: "女生群", message: "對唔住遲咗！剛剛三明治太多個，裝唔落袋，返屋企換咗個大袋～ 而家到灣仔站", timestamp: "09:05", date: "2025-06-29", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-29-5", sender: "阿琳", recipient: "女生群", message: "冇問題！城巴9點15分先開，仲有時間～", timestamp: "09:08", date: "2025-06-29", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-29-6", sender: "阿妹", recipient: "女生群", message: "我到喇！見到你地喇～ 黃色T恤好醒目", timestamp: "09:10", date: "2025-06-29", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-29-7", sender: "書記", recipient: "女生群", message: "終於到啦！三明治有芝士蛋同火腿蛋，大家揀啦", timestamp: "09:15", date: "2025-06-29", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-29-8", sender: "阿婷", recipient: "女生群", message: "我要火腿蛋～ 多謝書記！巴士來啦，快啲上車", timestamp: "09:18", date: "2025-06-29", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-29-9", sender: "阿琳", recipient: "女生群", message: "坐前排啦，風景好～ 阿妹你坐中間", timestamp: "09:20", date: "2025-06-29", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-29-10", sender: "阿妹", recipient: "女生群", message: "巴士開得好快啊～ 見到維多利亞港啦，好靚！", timestamp: "09:30", date: "2025-06-29", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-29-11", sender: "阿婷", recipient: "女生群", message: "我影咗張相，等陣send上群～ 海天一色", timestamp: "09:32", date: "2025-06-29", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-29-12", sender: "書記", recipient: "女生群", message: "快到啦！我聽到海洋公園個音樂喇～ 好興奮", timestamp: "09:40", date: "2025-06-29", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-29-13", sender: "阿琳", recipient: "女生群", message: "準備落車啦，大家拎好自己嘅嘢～ 學生證出嚟等住", timestamp: "09:42", date: "2025-06-29", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-29-14", sender: "阿妹", recipient: "女生群", message: "學生證在手！等陣入去第一時間去過山車～", timestamp: "09:45", date: "2025-06-29", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-29-15", sender: "書記", recipient: "女生群", message: "我同阿婷去企鵝館啦，你地玩完過山車找我地啦～ 電話保持通訊", timestamp: "09:50", date: "2025-06-29", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-29-16", sender: "阿琳", recipient: "女生群", message: "得～ 11點在旋轉木馬度集合啦", timestamp: "09:52", date: "2025-06-29", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-29-17", sender: "阿婷", recipient: "女生群", message: "BB企鵝好可愛啊！我影咗好多相～ 書記話佢地好似糯米糍", timestamp: "10:15", date: "2025-06-29", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-29-18", sender: "阿妹", recipient: "女生群", message: "過山車超刺激！阿琳叫到聲都沙咗～ 哈哈哈", timestamp: "10:20", date: "2025-06-29", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-29-19", sender: "阿琳", recipient: "女生群", message: "你先叫得大聲！全程捉住我隻手，指甲都入晒我肉", timestamp: "10:22", date: "2025-06-29", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-29-20", sender: "書記", recipient: "女生群", message: "我地準備去睇海豚表演啦，11點開始，你地要來嗎？", timestamp: "10:30", date: "2025-06-29", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-29-21", sender: "阿妹", recipient: "女生群", message: "來！我想去睇海豚～ 過山車玩一次夠晒", timestamp: "10:32", date: "2025-06-29", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-29-22", sender: "阿琳", recipient: "女生群", message: "我地在去表演場嘅路上，大概10:50到", timestamp: "10:35", date: "2025-06-29", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-29-23", sender: "阿婷", recipient: "女生群", message: "我地霸咗前排位，等你地～ 記得帶傘，陽光好猛", timestamp: "10:40", date: "2025-06-29", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-29-24", sender: "阿妹", recipient: "女生群", message: "見到你地喇！揮手揮手～", timestamp: "10:55", date: "2025-06-29", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-29-25", sender: "書記", recipient: "女生群", message: "海豚跳得好高啊！阿婷快啲影相～", timestamp: "11:10", date: "2025-06-29", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-29-26", sender: "阿琳", recipient: "女生群", message: "表演完咗，去食午餐啦？我帶咗零食，先墊下肚", timestamp: "11:30", date: "2025-06-29", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-29-27", sender: "阿妹", recipient: "女生群", message: "我要食草莓～ 好甜啊！", timestamp: "11:32", date: "2025-06-29", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-29-28", sender: "阿婷", recipient: "女生群", message: "我想去買芒果糯米糍，誰要？", timestamp: "11:40", date: "2025-06-29", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-29-29", sender: "書記", recipient: "女生群", message: "我要兩個！一個依家食，一個留返下午茶", timestamp: "11:42", date: "2025-06-29", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-29-30", sender: "阿琳", recipient: "女生群", message: "我要一個～ 阿妹你呢？", timestamp: "11:45", date: "2025-06-29", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-29-31", sender: "阿妹", recipient: "女生群", message: "我都要一個～ 多謝阿婷！", timestamp: "11:48", date: "2025-06-29", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-29-32", sender: "阿婷", recipient: "女生群", message: "買返來啦！熱辣辣～ 大家快啲食", timestamp: "12:00", date: "2025-06-29", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-29-33", sender: "書記", recipient: "女生群", message: "好好食啊！芒果好香～ 等陣去玩旋轉木馬嗎？", timestamp: "12:05", date: "2025-06-29", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-29-34", sender: "阿琳", recipient: "女生群", message: "好啊～ 旋轉木馬影相靚", timestamp: "12:08", date: "2025-06-29", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-29-35", sender: "阿妹", recipient: "女生群", message: "我要坐那隻白色馬！好靚", timestamp: "12:10", date: "2025-06-29", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-29-36", sender: "阿婷", recipient: "女生群", message: "我準備好相機啦，保證影到大家最靚嘅一面", timestamp: "12:15", date: "2025-06-29", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-29-37", sender: "阿琳", recipient: "女生群", message: "開始落雨啦！大家拎遮啦～ 細雨來得好快", timestamp: "14:30", date: "2025-06-29", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-29-38", sender: "書記", recipient: "女生群", message: "不如去室內玩？有個4D影院，聽日上映《超人》", timestamp: "14:35", date: "2025-06-29", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-29-39", sender: "阿妹", recipient: "女生群", message: "好啊！我最怕濕身～ 4D應該好刺激", timestamp: "14:38", date: "2025-06-29", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-29-40", sender: "阿婷", recipient: "女生群", message: "我地去買飛啦～ 15:00場，剛好有位", timestamp: "14:40", date: "2025-06-29", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),

  // 6/30 initial messages
  HkChatMessage(id: "gg-6-30-1", sender: "阿妹", recipient: "女生群", message: "昨日玩得好開心！雖然落咗陣雨，但係好過癮～ 阿婷啲相出咗未？", timestamp: "10:00", date: "2025-06-30", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-30-2", sender: "阿婷", recipient: "女生群", message: "就嚟整好啦！BB企鵝張相超可愛，我調咗色～ 等陣send上群", timestamp: "10:05", date: "2025-06-30", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-30-3", sender: "書記", recipient: "女生群", message: "我隻腳今日好痛啊... 行咗太多路", timestamp: "10:10", date: "2025-06-30", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-6-30-4", sender: "阿琳", recipient: "女生群", message: "我都係～ 不過魚蛋好正，值得！聽日去銅鑼灣行街嗎？買返啲日用品", timestamp: "10:15", date: "2025-06-30", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),

  // 8/28 initial messages
  HkChatMessage(id: "gg-8-28-1", sender: "阿琳", recipient: "女生群", message: "暑假就快結束啦... 聽日去旺角買開學用品好不好？", timestamp: "19:00", date: "2025-08-28", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-8-28-2", sender: "阿妹", recipient: "女生群", message: "好啊！我需要買新嘅筆記本同原子筆～ 旺角「學生天地」平好多", timestamp: "19:05", date: "2025-08-28", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-8-28-3", sender: "書記", recipient: "女生群", message: "我陪你地去～ 旺角有間「華星冰室」，下午茶好正，一齊去食", timestamp: "19:10", date: "2025-08-28", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
  HkChatMessage(id: "gg-8-28-4", sender: "阿婷", recipient: "女生群", message: "我要買新嘅畫筆，開學有美術課～ 聽日幾點？", timestamp: "19:15", date: "2025-08-28", isGroupChat: true, groupMembers: ["阿琳", "書記", "阿婷", "阿妹"]),
];

// Append merged external messages
// Merge lists at initialization
final List<HkChatMessage> mergedHkChatHistory = [
  ...hkChatHistory,
  ...girlsGroupAdditions,
];

// Helper functions
List<HkChatMessage> getMessagesByDate(String date) {
  return mergedHkChatHistory.where((msg) => msg.date == date).toList();
}

List<HkChatMessage> getPrivateChat(String person1, String person2) {
  return mergedHkChatHistory.where((msg) => 
    !msg.isGroupChat && 
    ((msg.sender == person1 && msg.recipient == person2) || 
     (msg.sender == person2 && msg.recipient == person1))
  ).toList();
}

List<HkChatMessage> getGroupChat(String groupName) {
  return mergedHkChatHistory.where((msg) => 
    msg.isGroupChat && msg.recipient == groupName
  ).toList();
}


