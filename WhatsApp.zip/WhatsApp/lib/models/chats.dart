import 'package:whatsapp_clone/models/messages.dart';
import 'package:whatsapp_clone/models/users.dart';



final userMessages = generateUserMessages(users);
List<Map<String, dynamic>> rawInboxMessages = [
  // Day 1 - 2025-08-27 (Wednesday) 禮拜三
  {
    "message": "喂！今晚落班去唔去尖沙咀食魚蛋？聽講間新開嘅好好味！🍢",
    "timeStamp": "17:30",
    "isSender": false,
    "date": "2025-08-27",
  },
  {
    "message": "得啊！不過MTR尖沙咀站個出口最近成日塞，不如我哋油麻地行過去？快啲㗎～",
    "timeStamp": "17:35",
    "isSender": true,
    "date": "2025-08-27",
  },
  {
    "message": "冇問題！我六點半落班，喺油麻地A2出口等你得唔得？",
    "timeStamp": "17:38",
    "isSender": false,
    "date": "2025-08-27",
  },
  {
    "message": "OK！我帶多張八達通畀你，上次見你話張卡冇錢㗎啦～",
    "timeStamp": "17:40",
    "isSender": true,
    "date": "2025-08-27",
  },
  {
    "message": "記得埋！仲要幫我加杯凍檸茶，少甜啊～😋",
    "timeStamp": "17:42",
    "isSender": false,
    "date": "2025-08-27",
  },
  {
    "message": "收到！今晚應該唔會落雨挂？晏晝睇天氣報告話多雲咋～",
    "timeStamp": "17:45",
    "isSender": true,
    "date": "2025-08-27",
  },

  // Day 2 - 2025-08-28 (Thursday) 禮拜四
  {
    "message": "早晨！琴晚啲魚蛋真係好正，下次試埋佢隔離嘅腸粉啦～",
    "timeStamp": "08:10",
    "isSender": false,
    "date": "2025-08-28",
  },
  {
    "message": "我都覺得！佢個辣醬夠香，不過你上次話想試灣仔間茶樓嘅點心，周末去唔去？",
    "timeStamp": "08:15",
    "isSender": true,
    "date": "2025-08-28",
  },
  {
    "message": "好啊！不過周末茶樓實要等位，不如早啲去？十點前到應該冇問題～",
    "timeStamp": "08:20",
    "isSender": false,
    "date": "2025-08-28",
  },
  {
    "message": "得！我周六朝早九點半喺灣仔站C出口等你，順便買杯熱奶茶過去～",
    "timeStamp": "08:22",
    "isSender": true,
    "date": "2025-08-28",
  },
  {
    "message": "正啊！記得唔好太甜，我鐘意「飛沙走奶」㗎～",
    "timeStamp": "08:25",
    "isSender": false,
    "date": "2025-08-28",
  },
  {
    "message": "收到！對咗，你上次托我買嘅港澳藥房嘅藥油，我已經買咗啦，周六一齊俾你～",
    "timeStamp": "08:28",
    "isSender": true,
    "date": "2025-08-28",
  },

  // Day 3 - 2025-08-29 (Friday) 禮拜五
  {
    "message": "喂！今日周五啦！放工去唔去銅鑼灣行街？想買件新T恤～",
    "timeStamp": "12:30",
    "isSender": false,
    "date": "2025-08-29",
  },
  {
    "message": "得啊！不過我要加班到六點，不如我哋七點喺時代廣場門口見？",
    "timeStamp": "12:35",
    "isSender": true,
    "date": "2025-08-29",
  },
  {
    "message": "冇問題！時代廣場隔離有間魚蛋王，等陣可以先食少少墊肚～",
    "timeStamp": "12:38",
    "isSender": false,
    "date": "2025-08-29",
  },
  {
    "message": "好！對咗，聽日去茶樓，你想食叉燒包定蓮蓉包？我預先同侍應留位時提下佢～",
    "timeStamp": "12:40",
    "isSender": true,
    "date": "2025-08-29",
  },
  {
    "message": "要叉燒包！最好係熱辣辣嘅，皮鬆鬆哋嘅那種～",
    "timeStamp": "12:42",
    "isSender": false,
    "date": "2025-08-29",
  },
  {
    "message": "收到！今晚可能有雷暴，記得帶遮啊～",
    "timeStamp": "12:45",
    "isSender": true,
    "date": "2025-08-29",
  },

  // Day 4 - 2025-08-30 (Saturday) 禮拜六
  {
    "message": "早晨！今日天氣几好喎，冇落雨～我而家出門，九點半到灣仔～",
    "timeStamp": "09:00",
    "isSender": false,
    "date": "2025-08-30",
  },
  {
    "message": "我都準備好啦！奶茶已經買咗，「飛沙走奶」少甜，等緊你～",
    "timeStamp": "09:10",
    "isSender": true,
    "date": "2025-08-30",
  },
  {
    "message": "到咗！見到你啦～喺你後面！",
    "timeStamp": "09:28",
    "isSender": false,
    "date": "2025-08-30",
  },
  {
    "message": "入去啦！我已經同侍應留咗張兩人枱，仲叫咗叉燒包同蝦餃～",
    "timeStamp": "09:30",
    "isSender": true,
    "date": "2025-08-30",
  },
  {
    "message": "正啊！呢間茶樓嘅點心真係唔錯，下次帶埋阿媽過嚟試下～",
    "timeStamp": "10:15",
    "isSender": false,
    "date": "2025-08-30",
  },
  {
    "message": "得啊！下次可以試埋佢嘅鳳爪，好淋好入味㗎～",
    "timeStamp": "10:18",
    "isSender": true,
    "date": "2025-08-30",
  },

  // Day 5 - 2025-08-31 (Sunday) 禮拜日
  {
    "message": "琴晚瞓得好唔好？我今朝十一點先醒，太好瞓啦～",
    "timeStamp": "11:30",
    "isSender": false,
    "date": "2025-08-31",
  },
  {
    "message": "我都係！今朝起身去咗樓下嘅茶餐廳食西多士，搽花生醬真係正～",
    "timeStamp": "11:35",
    "isSender": true,
    "date": "2025-08-31",
  },
  {
    "message": "好想吃啊！下次一齊去食啦，我要加個炒蛋同熱檸樂～",
    "timeStamp": "11:40",
    "isSender": false,
    "date": "2025-08-31",
  },
  {
    "message": "得！下周日啦？今個周日我要同屋企人去黃大仙拜拜～",
    "timeStamp": "11:42",
    "isSender": true,
    "date": "2025-08-31",
  },
  {
    "message": "OK！記得幫我求支好籤啊～最近想轉工，求個順利～",
    "timeStamp": "11:45",
    "isSender": false,
    "date": "2025-08-31",
  },
  {
    "message": "收到！一定幫你求支上上籤～😉",
    "timeStamp": "11:48",
    "isSender": true,
    "date": "2025-08-31",
  },

  // Day 6 - 2025-09-01 (Monday) 禮拜一
  {
    "message": "早晨！返工啦～今日MTR有冇塞車？我聽日要早啲出門，驚遲到～",
    "timeStamp": "08:00",
    "isSender": false,
    "date": "2025-09-01",
  },
  {
    "message": "今朝都几順，不過聽日有學生返學，可能會塞少少，你最好早15分鐘出門～",
    "timeStamp": "08:05",
    "isSender": true,
    "date": "2025-09-01",
  },
  {
    "message": "收到！多謝提醒～午飯一齊去食茶記啦？想食焗豬扒飯～",
    "timeStamp": "08:10",
    "isSender": false,
    "date": "2025-09-01",
  },
  {
    "message": "得啊！十二點半喺公司樓下見，我請你飲凍奶茶～",
    "timeStamp": "08:12",
    "isSender": true,
    "date": "2025-09-01",
  }
];
