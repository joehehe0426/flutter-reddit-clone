# WhatsApp clone

## Demo





## Overview
This is a WhatsApp mobile app clone. The mobile app is developed for both Android and iOS.

## Developer instructions
---
**NOTE**: 
* To run this project, you **MUST** install Flutter SDK on your machine. Refer to [Flutter's documentation](https://docs.flutter.dev/get-started/install) and follow a step-by-step guide on how you can install Flutter SDK on your OS.

* Make sure you have installed Android Studio or a text editor of your choice - VS Code or XCode.

* Make sure your machine supports virtualization - required to run an emulator. If it doesn't, don't worry, you can install `scrcpy` on your machine or use Android Studio's `mirror device` feature.

**Scrcpy Installation guide** 
* [Install scrcpy on Windows](https://github.com/Genymobile/scrcpy/blob/master/doc/windows.md)
* [Install scrcpy on Linux](https://github.com/Genymobile/scrcpy/blob/master/doc/linux.md)
* [Install scrcpy on MacOS](https://github.com/Genymobile/scrcpy/blob/master/doc/macos.md)

---

#### Installation guide for developers

1. Git clone
Clone this repository by opening your terminal/CMD and change the current working directory to Desktop - use `cd Desktop` command.
```bash
    $ cd Desktop
    $ git clone https://github.com/morikeli/whatsapp-clone.git
```

2. Open the cloned repository on your text editor and run this command:
```bash
    $ flutter run
```
3. Make sure you have a very strong internet connection so that the necessary gradle files can be downloaded. These files are necessary to build the project `apk` file.

---
**Keep in mind**:
* When building the application for the first time, it may take 10 - 15 minutes to finish the installation and build process.
* When running the application using the `flutter run` command, it may take atleast a minute to install the build files on a physical device.
---


## Contributor expectations
Incase of a bug or you wish to make a contribution, create a new branch using the git command `git checkout -b <name of your branch>` and create a pull request. Wait for review.

You can also open an issue using the `Issues` tab. The reported issue will be reviewed and formulate a solution to the problem.


### Request
Don't forget to star the repo 🌟😉

### User → Profile Photo mapping

| Chat ID | Username | Profile Photo |
| --- | --- | --- |
| hk_demo | 家庭群組 | assets/img/dps/1.jpg |
| hk_group_friends | 老友群 | assets/img/dps/2.jpg |
| hk_group_girls | 女生群 | assets/img/girls_talk.png |
| hk_akiang_ahui | 阿強 | assets/img/dps/4.jpg |
| hk_mama_mrs_chan | Auntie Apple | assets/img/dps/5.jpg |
| hk_family_grandpa | 爺爺 | assets/img/dps/6.jpg |
| hk_family_grandma | 奶奶 | assets/img/dps/7.jpg |
| hk_family_dad | 爸爸 | assets/img/dps/8.jpg |
| hk_family_mom | 媽媽 | assets/img/dps/9.jpg |
| hk_family_brother | 阿哥 | assets/img/dps/10.jpeg |
| hk_family_sister | 阿妹 | assets/img/dps/11.jpeg |
| hk_family_cousin | 表妹 | assets/img/dps/12.jpeg |
| hk_friend_akiang | 阿強 | assets/img/dps/13.jpg |
| hk_friend_ahui | 阿輝 | assets/img/dps/14.jpg |
| hk_friend_alin | 阿琳 | assets/img/dps/15.jpg |
| hk_friend_senior_brother | 師兄 | assets/img/dps/16.jpg |
| hk_friend_ating | 阿婷 | assets/img/dps/17.jpg |
| hk_neighbor_mrs_chan | 鄰居陳太 | assets/img/dps/18.jpg |
| hk_friend_secretary | 書記 | assets/img/dps/19.jpg |
| hk_cafe_uncle | Uncle Ben | assets/img/dps/20.jpg |
| hk_girl_mei | 阿美 | assets/img/dps/1.jpg |
| hk_girl_fung | 阿芳 | assets/img/dps/2.jpg |
| hk_girl_yuen | 阿圓 | assets/img/dps/3.jpg |
| hk_girl_choi | 阿彩 | assets/img/dps/4.jpg |
| hk_girl_jenny | Jenny | assets/img/dps/21.jpg |
| hk_girl_virg | Virg | assets/img/dps/20.jpg |
| pin_biz_sarah_vine | Sarah（Vine & Co.） | assets/img/Sarah.png |